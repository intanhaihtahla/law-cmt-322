<?PHP 
include('header.php'); 
?>
<link rel="stylesheet" type="text/css" href="style.css">
<!-- (PHP) bahagaian mengambil data mula ---------------------------------------- -->
<?PHP
//L1 : Memanggil fail connection.php
include('connection.php');

//L2 : Mengambil data GET
$alertID=$_GET['alertID'];

//L3 : Mencari data dipangkalan data
$sqlcari=mysqli_query($condb,"select* from clientalert where alertID='$alertID'");

//L4 : Mengambil data yang di cari di L3
$data=mysqli_fetch_array($sqlcari);

?>
<!-- (PHP) bahagaian mengambil data tamat -------------------------------------- -->

<!-- (html + PHP) bahagian form yang mempunyai data mula ----------------------- -->

<!-- // L5 : Menyediakan borang dan memaparkan data yang di L4-->
<div class="form-container">
    <form action='clientAlertUpdate.php' method='POST'>
        <div class="link-container">
        </div>
        <fieldset style="width:85%">
            <legend>Update below information</legend>
            <div class="form-group">
            <input type="hidden" id="alertID" name="alertID" value="<?php echo $data['alertID']; ?>" required>
            </div>
            <div class="form-group">
                <label for="clientID">Select the client ID:</label>
                <select name='clientID' id="clientID" required>
    <option disabled selected value="">Select the client</option>
    <?php 
    $sqlClients = "SELECT clientID, clientsName FROM clients";
    $resultClients = mysqli_query($condb, $sqlClients);
    while ($client = mysqli_fetch_assoc($resultClients)) {
        $selected = ($client['clientID'] == $data['clientID']) ? 'selected' : '';
        echo "<option value='" . $client['clientID'] . "' $selected>" . $client['clientID'] . " - " . $client['clientsName'] . "</option>";
    }
    ?>
</select>

            </div>
            <div class="form-group">
                <label for="HearingID">Select the hearing ID:</label>
                <select name='HearingID' id="HearingID" required>
    <option disabled selected value="">Select the hearing ID</option>
    <?php 
    $sqlHearings = "SELECT HearingID, HearingType FROM courthearing";
    $resultHearings = mysqli_query($condb, $sqlHearings);
    while ($hearing = mysqli_fetch_assoc($resultHearings)) {
        $selected = ($hearing['HearingID'] == $data['HearingID']) ? 'selected' : '';
        echo "<option value='" . $hearing['HearingID'] . "' $selected>" . $hearing['HearingID'] . " - " . $hearing['HearingType'] . "</option>";
    }
    ?>
</select>
            </div>
            <div class="form-group">
                <label for="statusAlert">Select status alert:</label>
                <select name='statusAlert' id="statusAlert" required>
    <option disabled selected value="">Select status alert</option>
    <option value='Pending'>Pending</option>
    <option value='In Progress'>Acknowledge</option>
    <option value='Not Yet'>Dismissed</option>
</select>
            </div>
            <div class="form-group">
                <input type='submit' class='button' value='Kemaskini'>
            </div>
        </fieldset>
    </form>
</div>
<!-- (html + PHP) bahagian form yang mempunyai data tamat ---------------------- -->


<!-- (PHP) bahagian mengemaskini data mula ------------------------------------- -->
<?PHP

//Langkah 6 : Menguju kewujudan data POST
if(!empty($_POST))
{
  # L2 : mengambil data POST
  $alertID=$_POST['alertID'];
    $clientID=$_POST['clientID'];
    $HearingID=$_POST['HearingID'];
    $statusAlert=$_POST['statusAlert'];
     
    //Langkah 9 : data validation

    //Langkah 9.1 : Menguji format NoKP
     
    //Langkah 9.2 : Mengelakkan dari pengguna meng disable kan akaun sendiri
  
    
    //Langkah 10 : Melaksanakan proses mengemaskini data
    $updateQuery = "UPDATE clientalert SET 
            clientID='$clientID', 
            HearingID='$HearingID', 
            statusAlert='$statusAlert'
            WHERE alertID='$alertID'";


    if(mysqli_query($condb, $updateQuery))
    {
        // langkah 10.1 : Jika berjaya, papar msg dan kembali ke fail pengguna_senarai.php
        echo "<script>alert('Kemaskini berjaya.'); 
        window.location.href='updateClientAlert.php';</script>";
    }
    else
    {
        // Langkah 10.2 : Jika Gagal, Papar msg dan kembali ke previous page
        echo "<script>alert('Kemaskini tidak berjaya.'); 
        window.history.back();
        </script>";
    }  

mysqli_close($condb);
}

?>
<!-- (PHP) bahagian mengemaskini data tamat ------------------------------------ -->

<?PHP 
include('footer.php'); 
?>