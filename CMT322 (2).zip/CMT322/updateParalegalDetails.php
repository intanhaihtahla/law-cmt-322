<!--Menghubungkan fail dengan connection dan header file-->
<?PHP
include('header.php');
include('connection.php');
?>
<!--Mengisytiharkan pembolehubah css-->

<!--Kawasan form HTML bermula-->
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
<div class="w3-container">
  <div class="w3-panel w3-padding-small w3-pale-green w3-bottombar w3-round-xlarge w3-topbar w3-border-green w3-border">
<p id='para1'>List of Paralegals</p>
</div>
</div>
<!-- Bahagian Form (HTML) Tamat -------------------- -->
<!-- Bahagian Insert data (PHP) mula --------------- -->
<!-- Bahagian Insert data (PHP) tamat --------------- -->

<!-- Bahagian papar data (HTML in PHP) mula ------------- -->
<br>
<fieldset style="width:100%">
<div class="w3-panel">
<p id='para2'>Paralegal Details</p>
<div>

<?PHP 
// Menyemak data POST
if(!empty($_POST))
{   
    // Mengambil data POST
    $paralegalID=$_POST['paralegalID'];
    $paralegalName=$_POST['paralegalName'];
    $clientID=$_POST['clientID'];
    $lawyerID=$_POST['lawyerID'];
    $clientsName=$_POST['clientsName'];
    $lawyerName=$_POST['lawyerName'];

}
?>

<?PHP 
// Lakukan query terhadap pangkalan data
$sqlselect = mysqli_query($condb, "
    SELECT p.paralegalID, p.paralegalName, p.clientID, c.clientsName, p.lawyerID, l.lawyerName 
    FROM paralegals p
    LEFT JOIN clients c ON p.clientID = c.clientID
    LEFT JOIN lawyers l ON p.lawyerID = l.lawyerID
");


echo"<table border='1' width='100%'>
<thead style='background-color: #1E384E; color: #FFFFFF;'>
    <tr>
        <th width='5%'>Bil</th>
        <th width='60%'>Paralegal ID</th>
        <th width='15%'>Paralegal Name</th>
        <th width='10%'>Client ID</th>
        <th width='10%'>Client Name</th>
        <th width='10%'>Lawyer id</th> 
        <th width='10%'>Lawyer Name</th>
    </tr>
    </thead>
    <tbody>";

$pembilang=1;
while($row = mysqli_fetch_array($sqlselect)){ 
    $bgColor = ($pembilang % 2 === 0) ? "#93ABB7" : "#FFFFFF";
    $textColor = ($pembilang % 2 === 0) ? "#1E384E" : "#000000";  
    echo "
    <tr style='background-color: " . $bgColor . "; color: " . $textColor . ";'>
        <td align='center'>" . $pembilang . "</td>
        <td>". htmlspecialchars($row['paralegalID'])."</td>
        <td>". htmlspecialchars($row['paralegalName'])."</td>
        <td>". htmlspecialchars($row['clientID'])."</td>
        <td>". htmlspecialchars($row['clientsName'])."</td>
        <td>". htmlspecialchars($row['lawyerID'])."</td>
        <td>". htmlspecialchars($row['lawyerName'])."</td>
        <td align='center'><a href='paralegalUpdate.php?paralegalID=" . $row['paralegalID'] . "'>Update</a></td>
        <td align='center'><a href='paralegalLawyer.php?paralegalID=" . $row['paralegalID'] . "' onClick=\"return confirm('Anda pasti ingin padam data ini?')\">Delete</a></td>
    </tr>";
    $pembilang++;
}

echo"</table></fieldset><br>";

mysqli_close($condb);
?>
<nav class="navigation">
        <a href="../index.php" class="nav-link">Home</a>
        <a href="createClientsDetails.php" class="nav-link">Create Clients</a>
        <a href="updateLawyersDetails.php" class="nav-link">Manage Lawyers</a>
        <a href="createParalegalDetails.php" class="nav-link">Create Paralegals</a>
        <a href="createAdminDetails.php" class="nav-link">Create Admins</a>
        <a href="updateAdminDetails.php" class="nav-link">Manage Admins</a>
    </nav>
<!-- Bahagian papar data (HTML in PHP) tamat ------------- -->
<?PHP
include('footer.php');
?>