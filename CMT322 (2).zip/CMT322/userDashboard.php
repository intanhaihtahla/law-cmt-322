<?php
// Start the PHP session
session_start();

// Include your database connection file
include('connection.php');
include('header.php');

// Prepare the SQL queries to count lawyers, paralegals, and admins
$queryLawyers = "SELECT COUNT(*) as lawyerCount FROM lawyers";
$queryParalegals = "SELECT COUNT(*) as paralegalCount FROM paralegals";
$queryAdmins = "SELECT COUNT(*) as adminCount FROM admin";

// Execute the queries and check for errors
$resultLawyers = mysqli_query($condb, $queryLawyers);
$resultParalegals = mysqli_query($condb, $queryParalegals);
$resultAdmins = mysqli_query($condb, $queryAdmins);

if (!$resultLawyers || !$resultParalegals || !$resultAdmins) {
    die('Error in SQL query: ' . mysqli_error($condb));
}

// Fetch the results
$lawyerCount = mysqli_fetch_assoc($resultLawyers)['lawyerCount'];
$paralegalCount = mysqli_fetch_assoc($resultParalegals)['paralegalCount'];
$adminCount = mysqli_fetch_assoc($resultAdmins)['adminCount'];

// Close the database connection
mysqli_close($condb);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>User Metrics Dashboard</title>
    <link rel="stylesheet" href="style.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>

<h1>User Metrics Dashboard</h1>

<!-- Container for the chart -->
<div class="chart-container">
  <canvas id="userChart" style="width: 800px; height: 400px;"></canvas>
</div>

<script>
// Prepare data for the chart
var userLabels = ['Lawyers', 'Paralegals', 'Admins'];
var userCounts = [<?php echo $lawyerCount; ?>, <?php echo $paralegalCount; ?>, <?php echo $adminCount; ?>];

var ctx = document.getElementById('userChart').getContext('2d');
var userChart = new Chart(ctx, {
    type: 'bar',
    data: {
        labels: userLabels,
        datasets: [{
            label: 'User Distribution',
            data: userCounts,
            backgroundColor: [
                'rgba(255, 99, 132, 0.2)',
                'rgba(54, 162, 235, 0.2)',
                'rgba(75, 192, 192, 0.2)'
            ],
            borderColor: [
                'rgba(255, 99, 132, 1)',
                'rgba(54, 162, 235, 1)',
                'rgba(75, 192, 192, 1)'
            ],
            borderWidth: 1
        }]
    },
    options: {
        responsive: false,
        maintainAspectRatio: false,
        scales: {
            y: {
                beginAtZero: true,
                grid: {
                    color: 'rgba(255, 255, 255, 0.5)'
                },
                ticks: {
                    color: '#fff'
                }
            },
            x: {
                grid: {
                    color: 'rgba(255, 255, 255, 0.5)'
                },
                ticks: {
                    color: '#fff'
                }
            }
        },
        plugins: {
            legend: {
                labels: {
                    color: '#fff'
                }
            }
        }
    }
});
</script>
<nav class="navigation">
        <a href="../index.php" class="nav-link">Home</a>
        <a href="createClientsDetails.php" class="nav-link">Create Clients</a>
        <a href="updateClientsDetails.php" class="nav-link">Manage Clients</a>
        <a href="createLawyerDetails.php" class="nav-link">Create Lawyer</a>
        <a href="updateLawyersDetails.php" class="nav-link">Manage Lawyers</a>
        <a href="createParalegalsDetails.php" class="nav-link">Create Paralegals</a>
        <a href="updateParalegalDetails.php" class="nav-link">Manage Paralegals</a>
        <a href="createAdminDetails.php" class="nav-link">Create Admins</a>
        <a href="updateAdminDetails.php" class="nav-link">Manage Admins</a>
    </nav>


</body>
</html>
<?php
include ('footer.php');
?>
