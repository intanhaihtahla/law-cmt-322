<?PHP 
include('header.php'); 
?>
<link rel="stylesheet" type="text/css" href="style.css">
<!-- (PHP) bahagaian mengambil data mula ---------------------------------------- -->
<?PHP
//L1 : Memanggil fail connection.php
include('connection.php');

//L2 : Mengambil data GET
$clientID=$_GET['clientID'];

//L3 : Mencari data dipangkalan data
$sqlcari=mysqli_query($condb,"select* from clients where clientID='$clientID'");

//L4 : Mengambil data yang di cari di L3
$data=mysqli_fetch_array($sqlcari);

?>
<!-- (PHP) bahagaian mengambil data tamat -------------------------------------- -->

<!-- (html + PHP) bahagian form yang mempunyai data mula ----------------------- -->

<!-- // L5 : Menyediakan borang dan memaparkan data yang di L4-->
<div class="form-container">
<form action='clientUpdate.php' method='POST'>
<fieldset style="width:85%">
<p id="para2">Update below information</p>
    <div class="contact-form-group">
            <input class="contact-form-input" type="text" id="clientsName" name="clientsName" required placeholder="Please insert exactly 10 digits">
            <label class="contact-form-label" for="clientsName">Client Name:</label>
        </div>
    
    <div>
        <input type="hidden" id="clientID" name="clientID" placeholder="Must be exactly 10 integer" value="<?PHP echo $data['clientID'];?>" required>
    </div>
    <div class="contact-form-group">
            <input class="contact-form-input" type="text" id="clientsCase" name="clientsCase" required placeholder="Please insert exactly 10 digits">
            <label class="contact-form-label" for="clientsCase">Client Case:</label>
        </div> 
    
    <tr><tr><td align='center'>
	<tr>
    <td align='right'>Case ID :</td>
    <td>
        <select name='caseID' required>
            <option disabled selected value> -- Select Case ID -- </option>
            <?php 
            $sqlCaseType = mysqli_query($condb, "SELECT DISTINCT caseID, caseDescription FROM case_details");
            while($row = mysqli_fetch_array($sqlCaseType)) {
                $selected = ($data['caseID'] == $row['caseID']) ? 'selected' : '';
                echo "<option value='".$row['caseID']."' $selected>".$row['caseID']. " - " . $row['caseDescription'] . "</option>";
            }
            ?>
        </select>
    </td>
</tr>


	</tr></tr>
    <tr>
        <td></td>
        <td><input type='submit' class='button' value='Kemaskini'></td>
    </tr>
</form>
        </div>
<!-- (html + PHP) bahagian form yang mempunyai data tamat ---------------------- -->


<!-- (PHP) bahagian mengemaskini data mula ------------------------------------- -->
<?PHP

//Langkah 6 : Menguju kewujudan data POST
if(!empty($_POST))
{
  # L2 : mengambil data POST
  $clientID = mysqli_real_escape_string($condb, $_POST['clientID']);
    $clientsName = mysqli_real_escape_string($condb, $_POST['clientsName']);
    $clientsCase = mysqli_real_escape_string($condb, $_POST['clientsCase']);
    $caseID = mysqli_real_escape_string($condb, $_POST['caseID']);

     
    //Langkah 9 : data validation

    //Langkah 9.1 : Menguji format NoKP
     
    //Langkah 9.2 : Mengelakkan dari pengguna meng disable kan akaun sendiri
  
    
    //Langkah 10 : Melaksanakan proses mengemaskini data
    $updateQuery = "UPDATE clients SET  
                clientsName='$clientsName',
                clientsCase='$clientsCase',
                caseID='$caseID' 
                WHERE clientID='$clientID'";

    if(mysqli_query($condb, $updateQuery))
    {
        // langkah 10.1 : Jika berjaya, papar msg dan kembali ke fail pengguna_senarai.php
        echo "<script>alert('Kemaskini berjaya.'); 
        window.location.href='updateClientsDetails.php';</script>";
    }
    else
    {
        // Langkah 10.2 : Jika Gagal, Papar msg dan kembali ke previous page
        echo "<script>alert('Kemaskini tidak berjaya.'); 
        window.history.back();
        </script>";
    }  

mysqli_close($condb);
}

?>
<!-- (PHP) bahagian mengemaskini data tamat ------------------------------------ -->
<nav class="navigation">
        <a href="../index.php" class="nav-link">Home</a>
        <a href="createClientsDetails.php" class="nav-link">Create Clients</a>
        <a href="updateClientsDetails.php" class="nav-link">Manage Clients</a>
        <a href="createLawyerDetails.php" class="nav-link">Create Lawyer</a>
        <a href="updateLawyersDetails.php" class="nav-link">Manage Lawyers</a>
        <a href="createClientsDetails.php" class="nav-link">Create Paralegals</a>
        <a href="updateParalegalDetails.php" class="nav-link">Manage Paralegals</a>
        <a href="createAdminDetails.php" class="nav-link">Create Admins</a>
        <a href="updateAdminDetails.php" class="nav-link">Manage Admins</a>
    </nav>
<?PHP 
include('footer.php'); 
?>