<html>
<head>
    <link rel="stylesheet" href="style3.css">
    <title>Login Law Firm</title>
</head>
<body>
    
<div>
    <p id="para1">Please login for staff and click guest user to see our service</p>
    <form action='' method='POST'>
        <table>
            <tr>
                <td align='right'><p class="login-label">Your ID:</p></td>
                <td><input type='text' name='adminID' placeholder='Contoh 010101010101' maxlength='12' required autofocus></td>
            </tr>
            <tr>
                <td align='right'><p class="login-label">Password :</p></td>
                <td><input type='password' name='password' placeholder='Contoh:Intan Comel' maxlength='13' required></td>
            </tr>
            <tr>
                <td></td>
                <td>
                    <button class="button" type="submit" style="vertical-align:middle"><span>Daftar masuk</span></button>
                </td>
            </tr>
        </table>
    </form>
    <!-- Separate form for the Guest User button -->
    <form action='' method='POST'>
        <button class="button" type="submit" name="guestUser" style="vertical-align:middle"><span>Guest User</span></button>
    </form>
</div>
</body>
</html>

<?php
// Start the session at the beginning of the script
include('connection.php');
session_start();

if (!empty($_POST)) {
    // If the guest user button was pressed
    if (isset($_POST['guestUser'])) {
        $_SESSION['userType'] = 'guest';
        header('Location: index.php'); // Redirect immediately to index.php
        exit();
    }

    // Otherwise, process login for admin, lawyer, or paralegal
    $userID = $_POST['adminID']; // Use the correct name of the form field for adminID
    $password = $_POST['password']; // Assuming plaintext password for the demonstration

    // Initialize user type
    $userType = null;

    // Check in admins
    $query = "SELECT * FROM admin WHERE adminID = ? AND password = ?";
    $stmt = mysqli_prepare($condb, $query);
    mysqli_stmt_bind_param($stmt, 'ss', $userID, $password);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if (mysqli_num_rows($result) == 1) {
        $userType = 'admin';
    } else {
        // Check in lawyers
        mysqli_stmt_prepare($stmt, "SELECT * FROM lawyers WHERE lawyerID = ? AND password = ?");
        mysqli_stmt_bind_param($stmt, 'ss', $userID, $password);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);

        if (mysqli_num_rows($result) == 1) {
            $userType = 'lawyer';
        } else {
            // Check in paralegals
            mysqli_stmt_prepare($stmt, "SELECT * FROM paralegals WHERE paralegalID = ? AND password = ?");
            mysqli_stmt_bind_param($stmt, 'ss', $userID, $password);
            mysqli_stmt_execute($stmt);
            $result = mysqli_stmt_get_result($stmt);

            if (mysqli_num_rows($result) == 1) {
                $userType = 'paralegal';
            }
        }
    }

    if ($userType) {
        // Fetch the user data
        $data = mysqli_fetch_assoc($result);

        // Set session variables
        $_SESSION['userID'] = $data[$userType . 'ID'];
        $_SESSION['userName'] = $data[$userType . 'Name'];
        $_SESSION['userType'] = $userType; // Store the user type in the session

        // Redirect to the main menu
        echo "<script>window.location.href='index.php';</script>";
    } else {
        // Redirect back with an error message
        echo "<script>alert('Daftar Masuk Gagal'); window.history.back();</script>";
    }

    mysqli_close($condb);
}

?>


