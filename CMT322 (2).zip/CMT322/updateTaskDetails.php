<!--Menghubungkan fail dengan connection dan header file-->
<?PHP
include('header.php');
include('connection.php');
?>
<!--Mengisytiharkan pembolehubah css-->

<!--Kawasan form HTML bermula-->
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
<div class="w3-container">
  <div class="w3-panel w3-padding-small w3-pale-green w3-bottombar w3-round-xlarge w3-topbar w3-border-green w3-border">
<p id='para1'>List of Tasks</p>
</div>
</div>
<!-- Bahagian Form (HTML) Tamat -------------------- -->
<!-- Bahagian Insert data (PHP) mula --------------- -->
<!-- Bahagian Insert data (PHP) tamat --------------- -->

<!-- Bahagian papar data (HTML in PHP) mula ------------- -->
<br>
<fieldset style="width:100%">
<div class="w3-panel">
<p id='para2'>Task Details</p>
<div>

<?PHP 
// Menyemak data POST
if(!empty($_POST))
{   
    // Mengambil data POST
    $taskID = $_POST['taskID'];
    $taskname = $_POST['taskname'];
    $taskdetails = $_POST['taskdetails'];
    $paralegalID = $_POST['paralegalID'];
    $lawyerID = $_POST['lawyerID'];
    $taskdatecreated = $_POST['taskdatecreated'];
    $taskduedate = $_POST['taskduedate'];
    $taskstatus = $_POST['taskstatus'];
    $paralegalName = $_POST['paralegalName'];
    $lawyerName = $_POST['lawyerName'];

}
?>

<?PHP 
// Lakukan query terhadap pangkalan data
$sqlselect = mysqli_query($condb, "
    SELECT t.taskID, t.taskname, t.taskdetails, p.paralegalID, l.lawyerID, t.taskdatecreated, t.taskduedate, t.taskstatus, p.paralegalName, l.lawyerName
    FROM `task management` t
    LEFT JOIN paralegals p ON t.paralegalID = p.paralegalID
    LEFT JOIN lawyers l ON t.lawyerID = l.lawyerID
");

echo "<table border='1' width='100%'>";
echo "<thead style='background-color: #1E384E; color: #FFFFFF;'>";
echo "<tr>";
echo "<th width='5%'>No</th>";
echo "<th width='20%'>Task ID</th>";
echo "<th width='15%'>Task Name</th>";
echo "<th width='10%'>Task Details</th>";
echo "<th width='10%'>Paralegal ID</th>";
echo "<th width='10%'>Paralegal Name</th>";
echo "<th width='10%'>Lawyer ID</th>";
echo "<th width='10%'>Lawyer Name</th>";
echo "<th width='10%'>Task Date Created</th>";
echo "<th width='10%'>Task Due Date</th>";
echo "<th width='10%'>Task Status</th>";
echo "<th width='10%'>Update</th>";
echo "<th width='10%'>Delete</th>";
echo "</tr>";
echo "</thead>";
echo "<tbody>";
$pembilang=1;
while ($row = mysqli_fetch_array($sqlselect)) {
    // Set the background color for odd rows
    $bgColor = ($pembilang % 2 === 0) ? "#93ABB7" : "#FFFFFF";
    // Set the text color for odd rows
    $textColor = ($pembilang % 2 === 0) ? "#1E384E" : "#000000";   
    echo "<tr style='background-color: " . $bgColor . "; color: " . $textColor . ";'>";
    echo "<td align='center'>" . $pembilang . "</td>";
        echo "<td>" . htmlspecialchars($row['taskID']) . "</td>";
        echo "<td>" . htmlspecialchars($row['taskname']) . "</td>";
        echo "<td>" . htmlspecialchars($row['taskdetails']) . "</td>";
        echo "<td>" . htmlspecialchars($row['paralegalID']) . "</td>";
        echo "<td>" . htmlspecialchars($row['paralegalName']) . "</td>";
        echo "<td>" . htmlspecialchars($row['lawyerID']) . "</td>";
        echo "<td>" . htmlspecialchars($row['lawyerName']) . "</td>";
        echo "<td>" . htmlspecialchars($row['taskdatecreated']) . "</td>";
        echo "<td>" . htmlspecialchars($row['taskduedate']) . "</td>";
        echo "<td>" . htmlspecialchars($row['taskstatus']) . "</td>";
        echo "<td align='center'><a href='taskUpdate.php?taskID=" . $row['taskID'] . "'>Update</a></td>";
        echo "<td align='center'><a href='deleteTask.php?taskID=" . $row['taskID'] . "' onClick=\"return confirm('Anda pasti ingin padam data ini?')\">Delete</a></td>";
        echo "</tr>";
    $pembilang++;
}

echo"</tbody></table></fieldset><br>";

mysqli_close($condb);
?>
<nav class="navigation">
        <a href="../index.php" class="nav-link">Home</a>
        <a href="createTaskDetails.php" class="nav-link">Create Task</a>
        <a href="createTaskDeadline.php" class="nav-link">Create Deadline</a>
        <a href="updateTaskDeadline.php" class="nav-link">Manage Deadline</a>
    </nav>
<!-- Bahagian papar data (HTML in PHP) tamat ------------- -->
<?PHP
include('footer.php');
?>