<?php
include('connection.php');
include('header.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Court Order</title>
    <meta name="description" content="Award Winning Family Lawyers">
    <link rel="icon" href="/favicon.ico">
    <link rel="stylesheet" href="style.css">
</head>
<body>
<main>
    <section class="hero">
        <img src="img/be-heard.jpg" alt="Be Heard" class="hero-image">
    </section>

    <div class="content-container">
        <h1>Know Court Order</h1>
        <p>Welcome to Court Order, where excellence in family law is not just a commitment, but a reality. We are proud to announce that our dedication to providing exceptional legal services has been recognized with a prestigious award in the field of family law.</p>
        <h2>Award Winning Family Lawyers</h2>
        <p>At Court Order, we understand the complexities and sensitivities that come with family law cases. Our team of experienced and compassionate family lawyers is committed to helping clients navigate through the challenges of divorce, child custody, spousal support, and other family-related legal matters. We believe in upholding the highest ethical standards while vigorously advocating for the best interests of our clients.</p>
    </div>

    <div class="strategy-section">
    <h1>Our strategy</h1>
    <div class="content-section">
        <div class="content-image">
            <img src="img/first-image.jpg" alt="Our Experience">
        </div>
        <div class="content-details">
            <h2>We stay up so you don’t have to!</h2>
            <p class="how">How?</p>
            <div class="experience-button">
                <span>Experience</span>
            </div>
            <p>Our team of family lawyers brings years of experience to the table. We have successfully represented countless clients, providing them with the legal support they need during emotionally challenging times.</p>
        </div>
    </div>
</div>

<div class="content-section reverse">
<div class="content-image">
        <img src="img/second-image.jpg" alt="Compassionate Consultation">
    </div>
    <div class="content-details">
    <div class="experience-button">
                <span>Compassion</span>
            </div>
        <h2>We understand that family law matters can be emotionally charged and difficult to navigate.</h2>
        <p>Our lawyers approach each case with empathy and sensitivity, ensuring that our clients feel supported throughout the legal process.</p>
    </div>
    
</div>
<div class="strategy-section">
    <div class="content-section">
        <div class="content-image">
            <img src="img/third-image.jpg" alt="Our Experience">
        </div>
        <div class="content-details">
            <h2>We stay up so you don’t have to!</h2>
            <div class="experience-button">
                <span>Strategic approach</span>
            </div>
            <p>Our attorneys are skilled strategists who carefully analyze each case to develop customized legal strategies tailored to our clients' unique situations. We are committed to achieving the best possible outcomes for our clients.</p>    </div>
</div>

<div class="content-section strategy">
    <div class="content-baru">
        <img src="img/fourth-image.jpg" alt="Our Strategy">
    </div>
    <div class="content-details strategy-details">
        <div class="strategy-item">
        <svg className="h-16 w-16 mb-4" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 64 64">
    {<path d="M56.9688 1.28125H8.03125C4.30333 1.28125 1.28125 4.30333 1.28125 8.03125V56.9688C1.28125 60.6967 4.30333 63.7188 8.03125 63.7188H56.9688C60.6967 63.7188 63.7188 60.6967 63.7188 56.9688V8.03125C63.7188 4.30333 60.6967 1.28125 56.9688 1.28125Z" stroke="#93ABB7" stroke-linecap="round" stroke-linejoin="round"/>}
{<path d="M47.2656 24.9062C45.3635 24.9062 43.5393 24.1506 42.1943 22.8057C40.8494 21.4607 40.0938 19.6365 40.0938 17.7344C40.0938 15.8323 39.3381 14.0081 37.9932 12.6631C36.6482 11.3181 34.824 10.5625 32.9219 10.5625H32.0781C30.176 10.5625 28.3518 11.3181 27.0068 12.6631C25.6619 14.0081 24.9062 15.8323 24.9062 17.7344C24.9062 19.6365 24.1506 21.4607 22.8057 22.8057C21.4607 24.1506 19.6365 24.9062 17.7344 24.9062C15.8323 24.9062 14.0081 25.6619 12.6631 27.0068C11.3181 28.3518 10.5625 30.176 10.5625 32.0781V32.9219C10.5625 
34.824 11.3181 36.6482 12.6631 37.9932C14.0081 39.3381 15.8323 40.0938 17.7344 40.0938C19.6365 40.0938 21.4607 40.8494 22.8057 42.1943C24.1506 43.5393 24.9062 45.3635 24.9062 47.2656C24.9063 49.1677 25.6619 50.9919 27.0068 52.3369C28.3518 53.6819 30.176 54.4375 
32.0781 54.4375H32.9219C34.824 54.4375 36.6482 53.6819 37.9932 52.3369C39.3381 50.9919 40.0937 49.1677 40.0938 47.2656C40.0938 45.3635 40.8494 43.5393 42.1943 42.1943C43.5393 40.8494 45.3635 40.0938 47.2656 40.0938C49.1677 40.0937 50.9919 39.3381 52.3369 37.9932C53.6819 36.6482 54.4375 34.824 54.4375 32.9219V32.0781C54.4375 30.176 53.6819 28.3518 52.3369 27.0068C50.9919 25.6619 49.1677 24.9063 47.2656 24.9062Z" stroke="#93ABB7" stroke-linecap="round" stroke-linejoin="round"/>}
{<path d="M48.3119 37.571C46.9671 36.226 46.2116 34.402 46.2116 32.5C46.2116 30.5981 46.9671 28.7741 48.3119 27.4291C49.6567 26.0841 50.4121 24.2601 50.4121 22.3582C50.4121 20.4562 49.6567 18.6322 48.3119 17.2872L47.7145 16.6898C46.3695 15.3451 44.5455 14.5896 42.6436 14.5896C40.7416 14.5896 38.9176 15.3451 37.5726 16.6898C36.9066 17.356 36.116 17.8844 35.2457 18.2449C34.3755 18.6054 33.4428 18.7909 32.5008 18.7909C31.5589 18.7909 30.6262 18.6054 29.756 
18.2449C28.8857 17.8844 28.0951 17.356 27.4291 16.6898C26.0841 15.3451 24.2601 14.5896 22.3581 14.5896C20.4562 14.5896 
18.6322 15.3451 17.2872 16.6898L16.6898 17.2855C15.345 18.6305 14.5896 20.4545 14.5896 22.3565C14.5896 24.2584 15.345 26.0825 16.6898 27.4274C17.3559 28.0934 17.8843 28.8841 18.2448 29.7543C18.6054 30.6245 18.7909 31.5573 18.7909 32.4992C18.7909 33.4411 18.6054 34.3739 18.2448 35.2441C17.8843 36.1143 17.3559 36.905 16.6898 37.571C15.345 38.9159 14.5896 40.74 14.5896 42.6419C14.5896 44.5438 15.345 46.3679 16.6898 47.7128L17.2855 48.3102C18.6305 49.655 20.4545 50.4105 22.3564 50.4105C24.2584 50.4105 
26.0824 49.655 27.4274 48.3102C28.0934 47.6441 28.8841 47.1157 29.7543 46.7552C30.6245 46.3947 31.5572 46.2091 
32.4992 46.2091C33.4411 46.2091 34.3738 46.3947 35.244 46.7552C36.1143 47.1157 36.905 47.6441 37.5709 48.3102C38.9159 49.655 40.74 50.4105 42.6419 50.4105C44.5438 50.4105 46.3679 49.655 47.7128 48.3102L48.3102 47.7145C49.655 46.3696 50.4104 44.5455 50.4104 42.6436C50.4104 40.7417 49.655 38.9176 48.3102 37.5727L48.3119 37.571Z" stroke="#93ABB7" stroke-linecap="round" stroke-linejoin="round"/>}
    </svg><div>
            Over 50 years of family law experience between us</div></div>
        <div class="strategy-item">
        <svg width="78" height="81" viewBox="0 0 78 81" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M11.1429 54.9643V52.0714H5.57143V54.9643C5.57143 60.3349 7.62589 65.4856 11.2828 69.2832C14.9398 73.0808 19.8997 75.2143 25.0714 75.2143H33.4286V69.4286H25.0714C21.3773 69.4286 17.8346 67.9047 15.2224 65.1921C12.6103 62.4795 11.1429 58.8004 11.1429 54.9643ZM61.2857 26.0357V28.9286H66.8571V26.0357C66.8571 20.6651 64.8027 15.5144 61.1457 11.7168C57.4888 7.91919 52.5289 5.78572 47.3571 5.78572H39V11.5714H47.3571C49.1863 11.5714 50.9975 11.9456 52.6874 12.6725C54.3773 13.3994 55.9127 14.4648 57.2061 15.8079C58.4995 17.1511 59.5255 18.7456 60.2255 20.5005C60.9254 22.2554 61.2857 24.1362 61.2857 26.0357ZM25.0714 26.0357H8.35714C6.14069 26.0357 4.01502 26.9501 2.44775 28.5776C0.880483 30.2052 0 32.4126 0 34.7143V40.5H5.57143V34.7143C5.57143 33.9471 5.86492 33.2112 6.38735 32.6687C6.90977 32.1262 7.61833 31.8214 8.35714 31.8214H25.0714C25.8102 31.8214 26.5188 32.1262 27.0412 32.6687C27.5637 33.2112 27.8571 33.9471 27.8571 34.7143V40.5H33.4286V34.7143C33.4286 32.4126 32.5481 30.2052 30.9808 28.5776C29.4136 26.9501 27.2879 26.0357 25.0714 26.0357ZM16.7143 23.1429C18.9181 23.1429 21.0725 22.4642 22.9049 21.1927C24.7374 19.9212 26.1656 18.114 27.0089 15.9996C27.8523 13.8852 28.073 11.5586 27.643 9.31396C27.2131 7.06932 26.1518 5.00749 24.5935 3.3892C23.0351 1.7709 21.0497 0.668833 18.8882 0.222347C16.7266 -0.224139 14.4862 0.00501364 12.4501 0.880828C10.414 1.75664 8.67373 3.23978 7.44934 5.14269C6.22495 7.0456 5.57143 9.28282 5.57143 11.5714C5.57143 14.6404 6.74541 17.5836 8.8351 19.7537C10.9248 21.9237 13.759 23.1429 16.7143 23.1429ZM16.7143 5.78572C17.8162 5.78572 18.8934 6.12505 19.8096 6.76079C20.7258 7.39653 21.4399 8.30013 21.8616 9.35734C22.2833 10.4145 22.3936 11.5779 22.1787 12.7002C21.9637 13.8225 21.4331 14.8534 20.6539 15.6626C19.8747 16.4717 18.882 17.0227 17.8012 17.246C16.7205 17.4692 15.6002 17.3546 14.5822 16.9167C13.5641 16.4788 12.694 15.7373 12.0818 14.7858C11.4696 13.8343 11.1429 12.7157 11.1429 11.5714C11.1429 10.037 11.7298 8.56535 12.7747 7.48031C13.8195 6.39528 15.2367 5.78572 16.7143 5.78572ZM69.6429 66.5357H52.9286C50.7121 66.5357 48.5864 67.4501 47.0192 69.0776C45.4519 70.7052 44.5714 72.9126 44.5714 75.2143V81H50.1429V75.2143C50.1429 74.4471 50.4364 73.7112 50.9588 73.1687C51.4812 72.6262 52.1898 72.3214 52.9286 72.3214H69.6429C70.3817 72.3214 71.0902 72.6262 71.6127 73.1687C72.1351 73.7112 72.4286 74.4471 72.4286 75.2143V81H78V75.2143C78 72.9126 77.1195 70.7052 75.5523 69.0776C73.985 67.4501 71.8593 66.5357 69.6429 66.5357ZM50.1429 52.0714C50.1429 54.36 50.7964 56.5973 52.0208 58.5002C53.2452 60.4031 54.9854 61.8862 57.0215 62.762C59.0576 63.6378 61.2981 63.867 63.4596 63.4205C65.6211 62.974 67.6066 61.872 69.1649 60.2537C70.7233 58.6354 71.7845 56.5735 72.2145 54.3289C72.6444 52.0843 72.4238 49.7576 71.5804 47.6432C70.737 45.5288 69.3088 43.7216 67.4764 42.4501C65.6439 41.1787 63.4896 40.5 61.2857 40.5C58.3304 40.5 55.4962 41.7191 53.4065 43.8892C51.3168 46.0593 50.1429 49.0025 50.1429 52.0714ZM66.8571 52.0714C66.8571 53.2157 66.5304 54.3343 65.9182 55.2858C65.306 56.2373 64.4359 56.9788 63.4178 57.4167C62.3998 57.8546 61.2795 57.9692 60.1988 57.746C59.118 57.5227 58.1253 56.9717 57.3461 56.1625C56.5669 55.3534 56.0363 54.3225 55.8213 53.2002C55.6064 52.0778 55.7167 50.9145 56.1384 49.8573C56.5601 48.8001 57.2742 47.8965 58.1904 47.2608C59.1066 46.625 60.1838 46.2857 61.2857 46.2857C62.7634 46.2857 64.1805 46.8953 65.2253 47.9803C66.2702 49.0653 66.8571 50.537 66.8571 52.0714Z" fill="#93ABB7"/>
</svg><div>
    
        All of our lawyers collaborate and strategize together</div></div>
        <div class="strategy-item">
        <svg width="64" height="57" viewBox="0 0 64 57" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M25.6 17.8125C22.08 17.8125 19.2 21.09 19.2 25.1156C19.2 27.1462 19.904 28.9275 21.088 30.2812L32 42.75L42.944 30.2812C44.096 28.9631 44.8 27.1106 44.8 25.1156C44.8 21.09 41.92 17.8125 38.4 17.8125C36.672 17.8125 35.04 18.6319 33.888 19.95L32 22.0875L30.144 19.9856C29.555 19.3043 28.8496 18.7611 28.0692 18.3879C27.2889 18.0147 26.4493 17.8191 25.6 17.8125ZM57.6 0C61.12 0 64 3.20625 64 7.125V49.875C64 53.7938 61.12 57 57.6 57H6.4C2.88 57 0 53.7938 0 49.875V7.125C0 3.20625 2.88 0 6.4 0H57.6ZM47.04 14.4638L57.6 7.125H6.4L16.96 14.4638C15.648 15.8531 14.56 17.5275 13.856 19.4156L6.4 14.25V49.875H57.6V14.25L50.144 19.4156C49.44 17.5275 48.352 15.8531 47.04 14.4638Z" fill="#93ABB7"/>
</svg><div>Special focus on complex family law issues including high net worth asset division and child abduction</div></div>
        <div class="strategy-item">
        <svg width="77" height="77" viewBox="0 0 77 77" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M28.2656 52.4813L38.1375 46.4906L48.0094 52.4813L45.3937 41.2594L54.1687 33.6656L42.6094 32.7375L38.1375 22.1063L33.6656 32.7375L22.1063 33.6656L30.8813 41.2594L28.2656 52.4813ZM38.1375 76.275L26.8312 65.1375H11.1375V49.4438L0 38.1375L11.1375 26.8312V11.1375H26.8312L38.1375 0L49.4438 11.1375H65.1375V26.8312L76.275 38.1375L65.1375 49.4438V65.1375H49.4438L38.1375 76.275Z" fill="#93ABB7"/>
</svg>
        <div>Voted as the #1 Top Divorce Lawyers</div>
</div>
</div></div>
<div>
    <div class="testimonials-section">
        <h1>What Our Clients Are Saying</h1>
        <svg width="100%" height="59" viewBox="0 0 792 59" fill="none" xmlns="http://www.w3.org/2000/svg">

<path d="M266.5 47.4174L284.113 59L279.439 37.17L295 22.4821L274.508 20.5879L266.5 0L258.491 20.5879L238 22.4821L253.561 37.17L248.887 59L266.5 47.4174Z" fill="#FFD233"/>
<path d="M329.5 47.4174L347.113 59L342.439 37.17L358 22.4821L337.508 20.5879L329.5 0L321.491 20.5879L301 22.4821L316.561 37.17L311.887 59L329.5 47.4174Z" fill="#FFD233"/>
<path d="M396.5 47.4174L414.113 59L409.439 37.17L425 22.4821L404.508 20.5879L396.5 0L388.491 20.5879L368 22.4821L383.561 37.17L378.887 59L396.5 47.4174Z" fill="#FFD233"/>
<path d="M463.5 47.4174L481.113 59L476.439 37.17L492 22.4821L471.508 20.5879L463.5 0L455.491 20.5879L435 22.4821L450.561 37.17L445.887 59L463.5 47.4174Z" fill="#FFD233"/>
<path d="M532.5 47.4174L550.113 59L545.439 37.17L561 22.4821L540.508 20.5879L532.5 0L524.491 20.5879L504 22.4821L519.561 37.17L514.887 59L532.5 47.4174Z" fill="#FFD233"/>
<line y1="29.5" x2="231" y2="29.5" stroke="#93ABB7"/>
        <line x1="561" y1="29.5" x2="100%" y2="29.5" stroke="#93ABB7"/>
    </svg>
    </div>
</div>

    <div class="contact-section">
        <h1>Contact Us</h1>
        <svg width="28" height="37" viewBox="0 0 28 37" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M28 25.6144L19.8015 24.3604L15.8812 29.5409C11.4649 26.5729 7.87524 21.8295 5.62917 15.9936L9.56507 10.7926L8.6161 0H0.0442402C-0.85806 20.9274 12.1631 38.1339 28 36.9415V25.6144Z" fill="#93ABB7"/>
</svg>
        <p>(+60) 133333333</p>
        <svg width="47" height="34" viewBox="0 0 47 34" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M42 8.5L23.3333 19.125L4.66667 8.5V4.25L23.3333 14.875L42 4.25M42 0H4.66667C2.07667 0 0 1.89125 0 4.25V29.75C0 30.8772 0.491665 31.9582 1.36683 32.7552C2.242 33.5522 3.42899 34 4.66667 34H42C43.2377 34 44.4247 33.5522 45.2998 32.7552C46.175 31.9582 46.6667 30.8772 46.6667 29.75V4.25C46.6667 3.12283 46.175 2.04183 45.2998 1.2448C44.4247 0.447766 43.2377 0 42 0Z" fill="#93ABB7"/>
</svg>

        <p>courtorder@gmail.com</p>

        <div class="contact-container">
    <h3 class="contact-title">Contact Us</h3>
    <form class="contact-form" action='' method="POST">
        <div class="contact-form-group">
            <input class="contact-form-input" type="text" id="name" name="name" required placeholder=" ">
            <label class="contact-form-label" for="name">Name</label>
        </div>
        <div class="contact-form-group">
            <input class="contact-form-input" type="email" id="email" name="email" required placeholder=" ">
            <label class="contact-form-label" for="email">Email</label>
        </div>
        <div class="contact-form-group">
            <textarea class="contact-form-input" id="message" name="message" required placeholder=" "></textarea>
            <label class="contact-form-label" for="message">Message</label>
        </div>
        <div class="contact-form-button">
            <button type="submit">Submit</button>
        </div>
    </form>
</div>
    </div>
    <?PHP 
// Menyemak data POST
// Check if POST data is not empty
if (!empty($_POST)) {
    // Retrieve data from POST
    $name = mysqli_real_escape_string($condb, $_POST['name']);
    $email = mysqli_real_escape_string($condb, $_POST['email']);
    $message = mysqli_real_escape_string($condb, $_POST['message']);
    // SQL query to check if the clientID exists in the database
    // Check if caseID exists in case_details table
$sqlCheckRegistering = "SELECT * FROM registering WHERE registerID = '$registerID'";
$resultCaseID = mysqli_query($condb, $sqlCheckRegistering);

    // The caseID exists, proceed with insertion into clients table
    $sqlInsertRegistration = "INSERT INTO registering (name, email, message) 
    VALUES 
    ('$name', '$email', '$message')";
    if (mysqli_query($condb, $sqlInsertRegistration)) {
        echo "<script>alert('Registration successful.');</script>";
    } else {
        echo "<script>alert('Registration failed: " . mysqli_error($condb) . "'); window.history.back();</script>";
    }

}

?>
</main>

</body>
</html>
<?php
include('footer.php');
?>