<?php
include('header.php');
?>
<link rel="stylesheet" type="text/css" href="style.css">
<!-- (PHP) bahagaian mengambil data mula ---------------------------------------- -->
<?php
// L1: Memanggil fail connection.php
include('connection.php');

// L2: Mengambil data GET
$HearingID = $_GET['HearingID'];

// L3: Mencari data di pangkalan data
$sqlcari = mysqli_query($condb, "SELECT * FROM courthearing WHERE HearingID='$HearingID'");

// L4: Mengambil data yang dicari di L3
$data = mysqli_fetch_array($sqlcari);
?>
<!-- (PHP) bahagaian mengambil data tamat -------------------------------------- -->

<!-- (html + PHP) bahagian form yang mempunyai data mula ----------------------- -->

<!-- // L5 : Menyediakan borang dan memaparkan data yang di L4-->
<div class="form-container">
    <form action='courtHearingUpdate.php' method='POST'>
    <table>
        <tr>
<p id="para2">Fill in the information below to update</p>
        <div class="w3-bar">
</div>
        </tr>
        <tr>
        <div class="contact-form-group">
            
            <label class="contact-form-label" for="HearingID">Hearing ID:</label>
            <input class="contact-form-input" type="text" id="HearingID" name="HearingID" value="<?php echo $data['HearingID']; ?>" required>
        </div>
        <td>
    <select name='caseID' required>
        <option disabled selected value>Case ID</option>
        <?php 
        $sqlCaseDetails = mysqli_query($condb, "SELECT caseID, caseType from case_details");
        while ($case = mysqli_fetch_array($sqlCaseDetails)) {
            echo "<option value='" . $case['caseID'] . "'>" . $case['caseID'] . " - " . $case['caseType'] . "</option>";
        }
        ?>
    </select>
</td>
<td>
    <select name='lawyerID' required>
        <option disabled selected value>Lawyer ID</option>
        <?php 
        $sqlLawyerDetails = mysqli_query($condb, "SELECT lawyerID, lawyerName from lawyers");
        while ($lawyer = mysqli_fetch_array($sqlLawyerDetails)) {
            echo "<option value='" . $lawyer['lawyerID'] . "'>" . $lawyer['lawyerID'] . " - " . $lawyer['lawyerName'] . "</option>";
        }
        ?>
    </select>
</td>
<td>
    <select name='clientID' required>
        <option disabled selected value>Client ID</option>
        <?php 
        $sqlClientDetails = mysqli_query($condb, "SELECT clientID, clientsName from clients");
        while ($client = mysqli_fetch_array($sqlClientDetails)) {
            echo "<option value='" . $client['clientID'] . "'>" . $client['clientID'] . " - " . $client['clientsName'] . "</option>";
        }
        ?>
    </select>
</td>      
            
    <td>
    <select name='HearingType' required>
    <option disabled selected value>Hearing Type</option>
    <?php 
    $sqlHearingTypeDetails = mysqli_query($condb, "SELECT HearingType from courthearing");
    while ($case = mysqli_fetch_array($sqlHearingTypeDetails)) {
        echo "<option value='" . $case['HearingType'] . "'>" . $case['HearingType'] . "</option>";
    }
    ?>
</select>
</td>
<div class="contact-form-group">
            
            <label class="contact-form-label" for="CourtRoom">Court Room:</label>
            <input class="contact-form-input" type="text" id="CourtRoom" name="CourtRoom" value="<?php echo $data['CourtRoom']; ?>" required>
        </div>
        <div class="contact-form-group">
        <label class="contact-form-label" for="Notes">Notes:</label>
            <input class="contact-form-input" type="text" id="Notes" name="Notes" value="<?php echo $data['Notes']; ?>" required>
            
        </div>
        <div>
        <label for="dateHearing"> Date Hearing:</label>
        <input type="date" id="dateHearing" name="dateHearing" required>
    </div>            
    <div>
        <label for="HearingTime">Hearing Time:</label>
        <input type="time" id="HearingTime" name="HearingTime" required>
    </div>
        <td><input type='submit' class='button' value='Kemaskini'></td>
        </tr>
    </table>
            

    </form>
</div>
<!-- (html + PHP) bahagian form yang mempunyai data tamat ---------------------- -->


<!-- (PHP) bahagian mengemaskini data mula ------------------------------------- -->
<?php

// Langkah 6: Menguju kewujudan data POST
if (!empty($_POST)) {
    # L2 : mengambil data POST
    $HearingID = mysqli_real_escape_string($condb, $_POST['HearingID']);
    $caseID = mysqli_real_escape_string($condb, $_POST['caseID']);
    $lawyerID = mysqli_real_escape_string($condb, $_POST['lawyerID']);
    $clientID = mysqli_real_escape_string($condb, $_POST['clientID']);
    $dateHearing = mysqli_real_escape_string($condb, $_POST['dateHearing']);
    $HearingTime = mysqli_real_escape_string($condb, $_POST['HearingTime']);
    $HearingType = mysqli_real_escape_string($condb, $_POST['HearingType']);
    $CourtRoom = mysqli_real_escape_string($condb, $_POST['CourtRoom']);
    $Notes = mysqli_real_escape_string($condb, $_POST['Notes']);

    // Langkah 9 : data validation

    // Langkah 9.1 : Menguji format NoKP

    // Langkah 9.2 : Mengelakkan dari pengguna meng disable kan akaun sendiri

    // Langkah 10 : Melaksanakan proses mengemaskini data
    $updateQuery = "UPDATE courthearing SET  
                dateHearing='$dateHearing',
                HearingTime='$HearingTime',
                CourtRoom='$CourtRoom',
                Notes='$Notes',
                caseID='$caseID',
                lawyerID='$lawyerID',
                clientID='$clientID'
                WHERE HearingID='$HearingID'";

    if (mysqli_query($condb, $updateQuery)) {
        // langkah 10.1 : Jika berjaya, papar msg dan kembali ke fail pengguna_senarai.php
        echo "<script>alert('Kemaskini berjaya.'); 
        window.location.href='updateCourtHearing.php';</script>";
    } else {
        // Langkah 10.2 : Jika Gagal, Papar msg dan kembali ke previous page
        echo "<script>alert('Kemaskini tidak berjaya.'); 
        window.history.back();
        </script>";
    }

    mysqli_close($condb);
}

?>
<!-- (PHP) bahagian mengemaskini data tamat ------------------------------------ -->
<nav class="navigation">
    <a href="../index.php" class="nav-link">Home</a>
    <a href="createClientAlert.php" class="nav-link">Create Client Alert</a>
    <a href="updateClientAlert.php" class="nav-link">Manage Client Alert</a>
    <a href="updateClientAlert.php" class="nav-link">Create Court Hearing</a>
</nav>
<?php
include('footer.php');
?>
