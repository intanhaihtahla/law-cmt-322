<?php 
include 'connection.php';
// Memulakan session
session_start();

if(isset($_GET['caseID'])) {
    // Using prepared statement
    $stmt = $condb->prepare("DELETE FROM case_details WHERE caseID = ?");
    $stmt->bind_param("s", $_GET['caseID']);

    if($stmt->execute()) {
        echo "<script>alert('Rekod telah dihapuskan'); window.location.href='caseUpdate.php';</script>";
    } else {
        echo "<script>alert('Rekod gagal dihapuskan'); window.history.back();</script>";
    }

    $stmt->close();
    mysqli_close($condb);
} else {
    echo "<script>alert('No caseID provided'); window.history.back();</script>";
}
?>
