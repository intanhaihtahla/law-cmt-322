<!--Menghubungkan fail dengan connection dan header file-->
<?PHP
include('header.php');
include('connection.php');
?>
<!--Mengisytiharkan pembolehubah css-->

<!--Kawasan form HTML bermula-->
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
<div class="w3-container">
  <div class="w3-panel w3-padding-small w3-pale-green w3-bottombar w3-round-xlarge w3-topbar w3-border-green w3-border">
<p id='para1'>List of Clients</p>
</div>
</div>
<!-- Bahagian Form (HTML) Tamat -------------------- -->
<!-- Bahagian Insert data (PHP) mula --------------- -->
<!-- Bahagian Insert data (PHP) tamat --------------- -->

<!-- Bahagian papar data (HTML in PHP) mula ------------- -->
<br>
<fieldset style="width:100%">
<div class="w3-panel">
<p id='para2'>Clients Details</p>
<div>

<?PHP 
// Menyemak data POST
if(!empty($_POST))
{   
    // Mengambil data POST
    $clientID = $_POST['clientID'];
    $clientsName=$_POST['clientsName'];
    $clientsCase=$_POST['clientsCase'];
    $caseID=$_POST['caseID'];
}
?>

<?PHP 
// Lakukan query terhadap pangkalan data
$sqlselect=mysqli_query($condb,"select* from clients");

echo"<table border='1' width='100%'>
    <tr>
        <th width='5%'>Bil</th>
        <th width='60%'>Client ID</th>
        <th width='15%'>Client Name</th>
        <th width='10%'>Client Case</th> 
        <th width='10%'>Case ID</th>
    </tr>";

$pembilang=1;
while($row=mysqli_fetch_array($sqlselect)){   
    $bgColor = ($pembilang % 2 === 0) ? "#93ABB7" : "#FFFFFF";
    // Set the text color for odd rows
    $textColor = ($pembilang % 2 === 0) ? "#1E384E" : "#000000";

    echo"
    <tr style='background-color: " . $bgColor . "; color: " . $textColor . ";'>
        <td align='center'>".$pembilang."</td>
        <td>" . htmlspecialchars($row['clientID']) . "</td>
        <td>" . htmlspecialchars($row['clientsName']) . "</td>
        <td>" . htmlspecialchars($row['clientsCase']) . "</td>
        <td>" . htmlspecialchars($row['caseID']) . "</td>
		<td align='center'><a href='clientUpdate.php?clientID=" . $row['clientID'] . "'>Update</a></td>
        <td align='center'><a href='deleteClient.php?clientID=" . $row['clientID'] . "' onClick=\"return confirm('Are you sure you want to delete this record?')\">Delete</a></td>
    </tr>";
    $pembilang++;
}
echo"</table></fieldset><br>";

mysqli_close($condb);
?>
<nav class="navigation">
        <a href="../index.php" class="nav-link">Home</a>
        <a href="createClientsDetails.php" class="nav-link">Create Clients</a>
        <a href="createLawyerDetails.php" class="nav-link">Create Lawyer</a>
        <a href="updateLawyersDetails.php" class="nav-link">Manage Lawyers</a>
        <a href="createClientsDetails.php" class="nav-link">Create Paralegals</a>
        <a href="updateParalegalDetails.php" class="nav-link">Manage Paralegals</a>
        <a href="createAdminDetails.php" class="nav-link">Create Admins</a>
        <a href="updateAdminDetails.php" class="nav-link">Manage Admins</a>
    </nav>
<?PHP
include('footer.php');
?>