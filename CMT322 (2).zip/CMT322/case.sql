-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 19, 2024 at 09:29 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cmt322`
--

-- --------------------------------------------------------

--
-- Table structure for table `case_details`
--

CREATE TABLE `case_details` (
  `id` int(11) NOT NULL,
  `caseID` varchar(255) NOT NULL,
  `caseType` varchar(255) NOT NULL,
  `caseDescription` text NOT NULL,
  `caseStatus` varchar(255) NOT NULL,
  `assignedAttorneyParalegalID` varchar(255) NOT NULL,
  `clientName` varchar(255) NOT NULL,
  `clientContactInformation` varchar(255) NOT NULL,
  `dateCreated` date NOT NULL,
  `caseDocuments` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `document_repository`
--

CREATE TABLE `document_repository` (
  `id` int(11) NOT NULL,
  `documentName` varchar(255) NOT NULL,
  `accessControl` varchar(50) NOT NULL,
  `uploadDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `fileStoragePath` varchar(255) NOT NULL,
  `currentVersion` int(11) NOT NULL,
  `fileSize` int(11) DEFAULT NULL,
  `fileType` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `document_versions`
--

CREATE TABLE `document_versions` (
  `id` int(11) NOT NULL,
  `documentId` int(11) NOT NULL,
  `versionNumber` int(11) NOT NULL,
  `versionDescription` text DEFAULT NULL,
  `versionUploadDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `fileStoragePath` varchar(255) NOT NULL,
  `fileSize` int(11) DEFAULT NULL,
  `fileType` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `case_details`
--
ALTER TABLE `case_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `document_repository`
--
ALTER TABLE `document_repository`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `document_versions`
--
ALTER TABLE `document_versions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `documentId` (`documentId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `case_details`
--
ALTER TABLE `case_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `document_repository`
--
ALTER TABLE `document_repository`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `document_versions`
--
ALTER TABLE `document_versions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `document_versions`
--
ALTER TABLE `document_versions`
  ADD CONSTRAINT `document_versions_ibfk_1` FOREIGN KEY (`documentId`) REFERENCES `document_repository` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
