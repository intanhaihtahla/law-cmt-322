<?PHP 
include('header.php'); 
?>
<link rel="stylesheet" type="text/css" href="style.css">
<!-- (PHP) bahagaian mengambil data mula ---------------------------------------- -->
<?PHP
//L1 : Memanggil fail connection.php
include('connection.php');

//L2 : Mengambil data GET
$taskID=$_GET['taskID'];

//L3 : Mencari data dipangkalan data
$sqlcari=mysqli_query($condb,"select* from `task management` where taskID='$taskID'");

//L4 : Mengambil data yang di cari di L3
$data=mysqli_fetch_array($sqlcari);

?>
<!-- (PHP) bahagaian mengambil data tamat -------------------------------------- -->

<!-- (html + PHP) bahagian form yang mempunyai data mula ----------------------- -->

<!-- // L5 : Menyediakan borang dan memaparkan data yang di L4-->

<div class="w3-panel ">
<p id='para2'>Update below information</p>
</div>
<div class="form-container">
<form action='taskUpdate.php' method='POST' lass="contact-form">

<tr>
<div class="contact-form-group">
    <label class="contact-form-label" for="taskname">Task Name:</label>
    <input class="contact-form-input" type="text" id="taskname" name="taskname" value="<?php echo $data['taskname']; ?>" required>   
</div>
    <div>
        <input type="hidden" id="taskID" name="taskID" placeholder="Must be exactly 10 integer" value="<?PHP echo $data['taskID'];?>" required>
    </div>
    <div class="contact-form-group">
    <label class="contact-form-label" for="taskdetails">Task Details:</label>
    <input class="contact-form-input" type="text" id="taskdetails" name="taskdetails" value="<?php echo $data['taskdetails']; ?>" required>   
</div>
    <div>
        <label for="taskdatecreated">Task Date Created:</label>
        <input type="date" id="taskdatecreated" name="taskdatecreated" placeholder="taskdatecreated" value="<?PHP echo $data['taskdatecreated'];?>" required>
    </div>
    <div>
        <label for="taskduedate">Task Due Date:</label>
        <input type="date" id="taskduedate" name="taskduedate" placeholder="taskduedate" value="<?PHP echo $data['taskduedate'];?>" required>
    </div>
    <td>
    <select name='paralegalID' required>
    <option disabled selected value>Paralegal ID - Paralegal Name</option>
    <?PHP 
    $sqlparalegal = mysqli_query($condb, "SELECT paralegalID, paralegalName from paralegals");
    while ($data = mysqli_fetch_array($sqlparalegal)) {
        echo "<option value='" . $data['paralegalID'] . "'>" . $data['paralegalID'] . " - " . $data['paralegalName'] . "</option>";
    }
    
    ?>
</select>

            </td>     
            <td> 
            <select name='lawyerID' required>
    <option disabled selected value> -- Select Lawyer ID -- </option>
    <?php 
    $sqlLawyers = mysqli_query($condb, "SELECT lawyerID, lawyerName from lawyers");
    while ($data = mysqli_fetch_array($sqlLawyers)) {
        echo "<option value='" . $data['lawyerID'] . "'>" . $data['lawyerID'] . " - " . $data['lawyerName'] . "</option>";
    }
    ?>
</select>
</td>
<select name='taskstatus' required>
    <option disabled selected value> --Task Status-- </option>
    <option value='Pending'>Pending</option>
    <option value='In Progress'>In Progress</option>
    <option value='Not Yet'>Not Yet</option>
    <option value='Completed'>Completed</option>
</select>
        </td>
        <td><input type='submit' class='button' value='Kemaskini'></td>
    </tr>
</form>
        </div>
<!-- (html + PHP) bahagian form yang mempunyai data tamat ---------------------- -->
<nav class="navigation">
        <a href="../index.php" class="nav-link">Home</a>
        <a href="createTaskDetails.php" class="nav-link">Create Task</a>
        <a href="updateTaskDetails.php" class="nav-link">Update Task</a>
        <a href="#" class="nav-link">Submit Document Here</a>
    </nav>

<!-- (PHP) bahagian mengemaskini data mula ------------------------------------- -->
<?PHP

//Langkah 6 : Menguju kewujudan data POST
if(!empty($_POST))
{
  # L2 : mengambil data POST
  $taskID = $_POST['taskID'];
    $taskname = $_POST['taskname'];
    $taskdetails = $_POST['taskdetails'];
    $paralegalID = $_POST['paralegalID'];
    $lawyerID = $_POST['lawyerID'];
    $taskdatecreated = $_POST['taskdatecreated'];
    $taskduedate = $_POST['taskduedate'];
    $taskstatus = $_POST['taskstatus'];
     
    //Langkah 9 : data validation

    //Langkah 9.1 : Menguji format NoKP
     
    //Langkah 9.2 : Mengelakkan dari pengguna meng disable kan akaun sendiri
  
    
    //Langkah 10 : Melaksanakan proses mengemaskini data
    $updateQuery = "UPDATE `task management` SET  
            taskname='$taskname',
            taskdetails='$taskdetails',
            paralegalID='$paralegalID',
            lawyerID='$lawyerID',
            taskdatecreated='$taskdatecreated',
            taskduedate='$taskduedate',
            taskstatus='$taskstatus'
            WHERE taskID='$taskID'";


    if(mysqli_query($condb, $updateQuery))
    {
        // langkah 10.1 : Jika berjaya, papar msg dan kembali ke fail pengguna_senarai.php
        echo "<script>alert('Kemaskini berjaya.'); 
        window.location.href='updateTaskDetails.php';</script>";
    }
    else
    {
        // Langkah 10.2 : Jika Gagal, Papar msg dan kembali ke previous page
        echo "<script>alert('Kemaskini tidak berjaya.'); 
        window.history.back();
        </script>";
    }  

mysqli_close($condb);
}

?>
<!-- (PHP) bahagian mengemaskini data tamat ------------------------------------ -->

<?PHP 
include('footer.php'); 
?>