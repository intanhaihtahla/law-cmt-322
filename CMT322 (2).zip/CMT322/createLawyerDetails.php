<!--Menghubungkan fail dengan connection dan header file-->
<?PHP
include('header.php');
include('connection.php');
?>
<!--Kawasan form HTML bermula-->
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
 <link rel="stylesheet" type="text/css" href="style.css">
<div class="w3-container">
  <div class="w3-panel w3-padding-small w3-pale-green w3-bottombar w3-round-xlarge w3-topbar w3-border-green w3-border">
<p id='para1'>Lawyer Details</p>
</div>
</div>
<fieldset style="width:85%">
<div class="w3-panel w3-pale-brown w3-leftbar w3-rightbar w3-border-blu">

    <p id='para2'>Fill in the information of the case</p>
</div>
<div class="form-container">
    <form action='' method='POST'>
    <table>
        <tr>

        <div class="w3-bar">
</div>
        </tr>
        <tr>
        <div class="contact-form-group">
            <input class="contact-form-input" type="text" id="lawyerID" name="lawyerID" required placeholder="Please insert exactly 10 digits">
            <label class="contact-form-label" for="lawyerID">Lawyer ID:</label>
        </div>
        <div class="contact-form-group">
            <input class="contact-form-input" type="text" id="lawyerName" name="lawyerName" required placeholder="Please insert exactly 10 digits">
            <label class="contact-form-label" for="lawyerName">Lawyer Name:</label>
        </div>
    <td>

    <select name='caseID' required>
    <option disabled selected value> -- Select Case ID -- </option>
    <?php 
    $sqlCaseDetails = mysqli_query($condb, "SELECT caseID, caseDescription from case_details");
    while ($case = mysqli_fetch_array($sqlCaseDetails)) {
        echo "<option value='" . $case['caseID'] . "'>" . $case['caseID'] . " - " . $case['caseDescription'] . "</option>";
    }
    ?>
</select>
            </td>      
            <td>
            <select name='clientID' required>
                <option disabled selected value>Client ID</option>
<!--Mengambil baris hasil dari jadual kategori-->
<?PHP 
    $sqlkelas = mysqli_query($condb, "SELECT clientID, clientsName from clients");
    while ($data = mysqli_fetch_array($sqlkelas)) {
        echo "<option value='" . $data['clientID'] . "'>" . $data['clientID'] . " - " . $data['clientsName'] . "</option>";
    }
    ?>
            </select>
            </td> 
            <td><button class='button'<span>Save</span></button></td>
        </tr>
    </table>
    </form>
            </div>
</fieldset>
<!-- Bahagian Form (HTML) Tamat -------------------- -->
<!-- Bahagian Insert data (PHP) mula --------------- -->
<?PHP 
// Menyemak data POST
if(!empty($_POST))
{   
    // Mengambil data POST
  
    $lawyerID=$_POST['lawyerID'];
    $lawyerName=$_POST['lawyerName'];
    $caseID=$_POST['caseID'];
    $clientID=$_POST['clientID'];

    //------------- data validation ---------------------------------------------------------
        //Data validation bagi no kad pengenalan bilangan digit & wujud aksara
 
            // SQL query to check if the caseID exists in the database
    $sqlchecklawyerID = "SELECT * FROM lawyers WHERE lawyerID = '$lawyerID'";
    $result = mysqli_query($condb, $sqlchecklawyerID);

    if (mysqli_num_rows($result) > 0) {
        // Case ID already exists in the database
        echo "Lawyer ID '$lawyerID' already exists in the database.";
    } else {
        // Case ID doesn't exist in the database
        echo "Lawyer ID '$lawyerID' is available and can be registered.";
    }
    //------------- Data validation ---------------------------------------------------------
    
    //Memasukkan data ke dalam jadual ahli
    if(mysqli_query($condb,"insert into lawyers
    (lawyerID, lawyerName, caseID, clientID) 
    VALUES ('$lawyerID', '$lawyerName', '$caseID', '$clientID')"))
    {
        echo"<script>alert('Pendaftaran berjaya');</script>";
    }
    else
    {
        echo"<script>alert('Pendaftaran Gagal');window.history.back();</script>";
    }
}
?>
<!-- Bahagian Insert data (PHP) tamat --------------- -->

<nav class="navigation">
        <a href="../index.php" class="nav-link">Home</a>
        <a href="createClientsDetails.php" class="nav-link">Create Clients</a>
        <a href="updateLawyersDetails.php" class="nav-link">Manage Lawyers</a>
        <a href="createClientsDetails.php" class="nav-link">Create Paralegals</a>
        <a href="updateParalegalDetails.php" class="nav-link">Manage Paralegals</a>
        <a href="createAdminDetails.php" class="nav-link">Create Admins</a>
        <a href="updateAdminDetails.php" class="nav-link">Manage Admins</a>
    </nav>

<!-- Bahagian papar data (HTML in PHP) tamat ------------- -->
<?PHP
include('footer.php');
?>