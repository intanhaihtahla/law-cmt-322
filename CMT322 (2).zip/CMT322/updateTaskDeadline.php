<!--Menghubungkan fail dengan connection dan header file-->
<?PHP
include('header.php');
include('connection.php');
?>
<!--Mengisytiharkan pembolehubah css-->

<!--Kawasan form HTML bermula-->
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
<div class="w3-container">

</div>
</div>
<!-- Bahagian Form (HTML) Tamat -------------------- -->
<!-- Bahagian Insert data (PHP) mula --------------- -->
<!-- Bahagian Insert data (PHP) tamat --------------- -->

<!-- Bahagian papar data (HTML in PHP) mula ------------- -->
<br>
<fieldset style="width:100%">
<div class="w3-panel">
<p id='para2'>Task Deadline Details</p>
<div>

<?PHP 
// Menyemak data POST
if(!empty($_POST))
{   
    // Mengambil data POST
    $taskID=$_POST['taskID'];
    $taskdeadline=$_POST['taskdeadline'];
    $status=$_POST['status'];
    $priority=$_POST['priority'];
}
?>

<?PHP 
// Lakukan query terhadap pangkalan data
$sqlselect = mysqli_query($condb, "
    SELECT td.taskID, td.taskdeadline, td.status, td.priority, tm.taskname, tm.paralegalName, tm.lawyerName
    FROM taskdeadline td
    LEFT JOIN `task management` tm ON td.taskID = tm.taskID
");

// Check if the query was successful
if (!$sqlselect) {
    die('Error in SQL query: ' . mysqli_error($condb));
}
echo "<table border='1' width='100%'>";
echo "<thead style='background-color: #1E384E; color: #FFFFFF;'>";
echo "<tr>";
echo "<th width='3%'>No</th>";
echo "<th width='6%'>Task ID</th>";
echo "<th width='19%'>Task Name</th>";
echo "<th width='11%'>Task Deadline</th>";
echo "<th width='15%'>Person in Charge</th>";
echo "<th width='15%'>Assigned by</th>";
echo "<th width='15%'>Status</th>";
echo "<th width='10%'>Priority</th>";
echo "<th width='10%'>Update</th>";
echo "<th width='10%'>Delete</th>";
echo "</tr>";
echo "</thead>";
echo "<tbody>";
$pembilang = 1;
while($row = mysqli_fetch_array($sqlselect)){   
    $bgColor = ($pembilang % 2 === 0) ? "#93ABB7" : "#FFFFFF";
    // Set the text color for odd rows
    $textColor = ($pembilang % 2 === 0) ? "#1E384E" : "#000000";  
    echo "<tr style='background-color: " . $bgColor . "; color: " . $textColor . ";'>";
    echo "<td align='center'>" . $pembilang . "</td>"; 
    echo "<td>" . htmlspecialchars($row['taskID']) . "</td>";
    echo "<td>" . htmlspecialchars($row['taskname']) . "</td>";
    echo "<td>" . htmlspecialchars($row['taskdeadline']) . "</td>";
    echo "<td>" . htmlspecialchars($row['paralegalName']) . "</td>";
    echo "<td>" . htmlspecialchars($row['lawyerName']) . "</td>";
    echo "<td>" . htmlspecialchars($row['status']) . "</td>";
    echo "<td>" . htmlspecialchars($row['priority']) . "</td>";
    echo "<td align='center'><a href='taskdeadlineUpdate.php?taskID=" . $row['taskID'] . "'>Update</a></td>";
    echo "<td align='center'><a href='deleteTaskDeadline.php?taskID=" . $row['taskID'] . "' onClick=\"return confirm('Anda pasti ingin padam data ini?')\">Delete</a></td>";
    echo "</tr>";
    $pembilang++;
}
    
echo"</table></fieldset><br>";

mysqli_close($condb);
?>
<nav class="navigation">
        <a href="../index.php" class="nav-link">Home</a>
        <a href="createTaskDetails.php" class="nav-link">Create Task</a>
        <a href="updateTaskDetails.php" class="nav-link">Manage Task</a>
        <a href="createTaskDeadline.php" class="nav-link">Create Deadline</a>
    </nav>
<!-- Bahagian papar data (HTML in PHP) tamat ------------- -->
<?PHP
include('footer.php');
?>