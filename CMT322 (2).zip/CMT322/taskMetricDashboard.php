<?php
// Start the PHP session
session_start();

// Include your database connection file
include('connection.php'); // Goes up one directory level and includes the connection.php file
include('header.php'); 
// Prepare the SQL query
$query = "SELECT taskstatus, COUNT(*) as statusCount FROM `task management` GROUP BY taskstatus";

// Execute the query and check for errors
$result = mysqli_query($condb, $query);
if (!$result) {
    die('Error in SQL query: ' . mysqli_error($condb));
}

// Fetch the results
$statusData = [];
while ($row = mysqli_fetch_assoc($result)) {
    $statusData[$row['taskstatus']] = $row['statusCount'];
}

// Close the database connection
mysqli_close($condb);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Case Metrics Dashboard</title>
    <link rel="stylesheet" href="style.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script> <!-- Include Chart.js -->
</head>
<body>

<h1>Task Status Chart</h1>

<!-- Container for the chart -->
<div class="chart-container">
  <canvas id="statusChart" style="width: 800px; height: 400px;"></canvas>
</div>


<script>
// Ensure that PHP is echoing out the data correctly and that it is a valid JavaScript array
var statusLabels = <?php echo json_encode(array_keys($statusData)); ?>;
var statusCounts = <?php echo json_encode(array_values($statusData)); ?>;

var ctx = document.getElementById('statusChart').getContext('2d');
var statusChart = new Chart(ctx, {
    type: 'bar',
    data: {
        labels: statusLabels,
        datasets: [{
            label: 'Task Status',
            data: statusCounts,
            backgroundColor: [
                'rgba(255, 99, 132, 0.2)',
                'rgba(54, 162, 235, 0.2)',
                'rgba(255, 206, 86, 0.2)',
                'rgba(75, 192, 192, 0.2)'
            ],
            borderColor: [
                'rgba(255, 99, 132, 1)',
                'rgba(54, 162, 235, 1)',
                'rgba(255, 206, 86, 1)',
                'rgba(75, 192, 192, 1)'
            ],
            borderWidth: 1
        }]
    },
    options: {
  responsive: false,
  maintainAspectRatio: false,
  scales: {
    y: {
      beginAtZero: true,
      grid: {
        color: 'rgba(255, 255, 255, 0.5)' // Set Y-axis grid line color to white with some transparency
      },
      ticks: {
        color: '#fff' // Set Y-axis tick labels to white
      }
    },
    x: {
      grid: {
        color: 'rgba(255, 255, 255, 0.5)' // Set X-axis grid line color to white with some transparency
      },
      ticks: {
        color: '#fff' // Set X-axis tick labels to white
      }
    }
  },
  plugins: {
    legend: {
      labels: {
        color: '#fff' // Set legend text to white
      }
    }
  }
}


});
</script>
<nav class="navigation">
        <a href="../index.php" class="nav-link">Home</a>
        <a href="createTaskDetails.php" class="nav-link">Create Task</a>
        <a href="updateTaskDetails.php" class="nav-link">Manage Task</a>
        <a href="createTaskDeadline.php" class="nav-link">Create Deadline</a>
        <a href="updateTaskDeadline.php" class="nav-link">Update Deadline</a>
    </nav>


</body>
</html>
<?php
include ('footer.php');
?>
