<?php
include('header.php');
include('connection.php');
?>

<div class="w3-container">
  <div class="w3-panel w3-padding-small w3-pale-green w3-bottombar w3-round-xlarge w3-topbar w3-border-green w3-border">
    <p id='para1'>List of Assignation Details</p>
  </div>
</div>
<br>
<fieldset style="width:100%">
<div class="w3-panel">
    <p id='para2'>Assignation Details</p>

    <?php
    // Query to join admin, lawyers, and case_details tables
    $sqlselect = mysqli_query($condb, "
        SELECT 
            a.adminID, a.adminName, a.caseID, a.lawyerID, a.paralegalID, a.reasonAssignation, 
            l.lawyerName, 
            c.caseDescription,
            p.paralegalName
        FROM admin a
        LEFT JOIN lawyers l ON a.lawyerID = l.lawyerID
        LEFT JOIN case_details c ON a.caseID = c.caseID
        LEFT JOIN paralegals p ON a.paralegalID = p.paralegalID
    ");

    echo "<table border='1' width='100%'>";
    echo "<thead style='background-color: #1E384E; color: #FFFFFF;'>";
    echo "<tr>";
    echo "<th width='5%'>No</th>";
    echo "<th width='20%'>Admin Name</th>";
    echo "<th width='15%'>Admin ID</th>";
    echo "<th width='10%'>Case ID</th>";
    echo "<th width='10%'>Case Description</th>";
    echo "<th width='10%'>Lawyer Name</th>";
    echo "<th width='10%'>Reason for Assignation</th>";
    echo "<th width='10%'>Update</th>";
    echo "<th width='10%'>Delete</th>";
    echo "</tr>";
    echo "</thead>";
    echo "<tbody>";

    $pembilang = 1;
    while ($row = mysqli_fetch_array($sqlselect)) {
        $bgColor = ($pembilang % 2 === 0) ? "#93ABB7" : "#FFFFFF";
        $textColor = ($pembilang % 2 === 0) ? "#1E384E" : "#000000";

        echo "<tr style='background-color: " . $bgColor . "; color: " . $textColor . ";'>";
        echo "<td align='center'>" . $pembilang . "</td>";
        echo "<td>" . htmlspecialchars($row['adminName']) . "</td>";
        echo "<td>" . htmlspecialchars($row['adminID']) . "</td>";
        echo "<td>" . htmlspecialchars($row['caseID']) . "</td>";
        echo "<td>" . htmlspecialchars($row['caseDescription']) . "</td>";
        echo "<td>" . htmlspecialchars($row['lawyerName']) . "</td>";
        echo "<td>" . htmlspecialchars($row['reasonAssignation']) . "</td>";
        echo "<td align='center'><a href='adminUpdate.php?adminID=" . $row['adminID'] . "'>Update</a></td>";
        echo "<td align='center'><a href='deleteAdmin.php?adminID=" . $row['adminID'] . "' onClick=\"return confirm('Are you sure you want to delete this record?')\">Delete</a></td>";
        echo "</tr>";

        $pembilang++;
    }

    echo "</tbody>";
    echo "</table>";
    echo "</fieldset><br>";

    mysqli_close($condb);
    ?>

    <nav class="navigation">
        <a href="../index.php" class="nav-link">Home</a>
        <a href="createLawyerDetails.php" class="nav-link">Create Lawyer</a>
        <a href="updateLawyersDetails.php" class="nav-link">Manage Lawyers</a>
        <a href="createClientsDetails.php" class="nav-link">Create Paralegals</a>
        <a href="updateParalegalDetails.php" class="nav-link">Manage Paralegals</a>
        <a href="createAdminDetails.php" class="nav-link">Create Admins</a>
        <a href="adminUpdate.php" class="nav-link">Manage Admins</a>
    </nav>
</div>

<?php include('footer.php'); ?>
