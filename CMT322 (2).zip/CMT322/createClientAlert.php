<!--Menghubungkan fail dengan connection dan header file-->
<?PHP
include('header.php');
include('connection.php');
?>
<!--Kawasan form HTML bermula-->
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
 <link rel="stylesheet" type="text/css" href="style.css">
<div class="w3-container">
  <div class="w3-panel w3-padding-small w3-pale-green w3-bottombar w3-round-xlarge w3-topbar w3-border-green w3-border">
<p id='para1'>Client Alert Details</p>
</div>
</div>
<fieldset style="width:85%">
<div class="w3-panel w3-pale-brown w3-leftbar w3-rightbar w3-border-blu">

    <p id='para2'>Fill in the information of the client alert</p>
</div>
<div class="form-container">
    <form action='' method='POST' lass="contact-form">
    <table>
        <tr>
        <div class="contact-form-group">
            <input class="contact-form-input" type="text" id="alertID" name="alertID" required placeholder="Please insert exactly 5 digits">
            <label class="contact-form-label" for="alertID">Alert ID:</label>
        </div>
    <td>
    <select name='HearingID' required>
    <option disabled selected value>--Hearing ID - Client--</option>
    <?PHP 
    // Adjust the query to also select the name of the paralegal
    $sqlhearing = mysqli_query($condb, "SELECT HearingID, clientsName from courthearing, clients");
    while ($data = mysqli_fetch_array($sqlhearing)) {
        // Display both the paralegalID and paralegalName in the option text
        echo "<option value='" . $data['HearingID'] . "'>" . $data['HearingID'] . " - " . $data['clientsName'] . "</option>";
    }
    ?>
            </select>
            </td>      
            <td>
            
<select name='statusAlert' required>
    <option disabled selected value>Select status alert</option>
    <option value='Pending'>Pending</option>
    <option value='In Progress'>Acknowledge</option>
    <option value='Not Yet'>Dismissed</option>
</select>

            </td> 
            <td><button class='button'<span>Save</span></button></td>
        </tr>
    </table>
    </form>
            </div>
            <nav class="navigation">
        <a href="../index.php" class="nav-link">Home</a>
         <a href="updateClientAlert.php" class="nav-link">Manage Client Alert</a>
    </nav>
</fieldset>
<!-- Bahagian Form (HTML) Tamat -------------------- -->
<!-- Bahagian Insert data (PHP) mula --------------- -->
<?PHP 
// Menyemak data POST
// Check if POST data is not empty
if (!empty($_POST)) {
    // Retrieve data from POST
    $alertID = mysqli_real_escape_string($condb, $_POST['alertID']);
    $HearingID = mysqli_real_escape_string($condb, $_POST['HearingID']);
    $statusAlert = mysqli_real_escape_string($condb, $_POST['statusAlert']);

    // SQL query to get clientID associated with the HearingID
    $sqlGetClientID = "SELECT clientID FROM courthearing WHERE HearingID = '$HearingID'";
    $resultClientID = mysqli_query($condb, $sqlGetClientID);

    if ($row = mysqli_fetch_assoc($resultClientID)) {
        // Fetch the clientID
        $clientID = $row['clientID'];

        // Insert the new alert with clientID, HearingID, and statusAlert
        $sqlInsertAlert = "INSERT INTO clientalert (alertID, clientID, HearingID, statusAlert) 
                           VALUES ('$alertID', '$clientID', '$HearingID', '$statusAlert')";
        if (mysqli_query($condb, $sqlInsertAlert)) {
            echo "<script>alert('Alert registration successful.');</script>";
        } else {
            echo "<script>alert('Alert registration failed: " . mysqli_error($condb) . "'); window.history.back();</script>";
        }
    } else {
        // HearingID does not exist or does not have an associated clientID
        echo "<script>alert('Invalid Hearing ID or no associated client found.'); window.history.back();</script>";
    }
}

?>
<!-- Bahagian Insert data (PHP) tamat --------------- -->



<!-- Bahagian papar data (HTML in PHP) tamat ------------- -->
<?PHP
include('footer.php');
?>