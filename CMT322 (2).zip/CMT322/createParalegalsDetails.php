<!--Menghubungkan fail dengan connection dan header file-->
<?PHP
include('header.php');
include('connection.php');
?>
<!--Kawasan form HTML bermula-->
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
 <link rel="stylesheet" type="text/css" href="style.css">
<div class="w3-container">
  <div class="w3-panel w3-padding-small w3-pale-green w3-bottombar w3-round-xlarge w3-topbar w3-border-green w3-border">
<p id='para1'>Paralegal Details</p>
</div>
</div>
<fieldset style="width:85%">
<div class="w3-panel w3-pale-brown w3-leftbar w3-rightbar w3-border-blu">

    <p id='para2'>Fill in the information of the case</p>
</div>
<div class="form-container">
    <form action='' method='POST'>
    <table>
        <tr>

        <div class="w3-bar">
</div>
        </tr>
        <tr>
        <div class="contact-form-group">
            <input class="contact-form-input" type="text" id="paralegalID" name="paralegalID" required placeholder="Please insert exactly 10 digits">
            <label class="contact-form-label" for="paralegalID">Paralegal ID:</label>
        </div>
        <div class="contact-form-group">
            <input class="contact-form-input" type="text" id="paralegalName" name="paralegalName" required placeholder="Please insert exactly 10 digits">
            <label class="contact-form-label" for="paralegalName">Paralegal Name:</label>
        </div>
        <div>
    <td>

    <select name='clientID' required>
    <option disabled selected value>Client ID</option>
    <?PHP 
    $sqlclient = mysqli_query($condb, "SELECT DISTINCT clientID, clientsName from clients");
    while ($data = mysqli_fetch_array($sqlclient)) {
        echo "<option value='" . $data['clientID'] . "'>" . $data['clientID'] . " - " . $data['clientsName'] . "</option>";
    }
    ?>
</select>

            </td>      
            <select name='lawyerID' required>
    <option disabled selected value> -- Select Lawyer ID -- </option>
    <?php 
    $sqlLawyers = mysqli_query($condb, "SELECT DISTINCT lawyerID, lawyerName from lawyers");
    while ($data = mysqli_fetch_array($sqlLawyers)) {
        echo "<option value='" . $data['lawyerID'] . "'>" . $data['lawyerID'] . " - " . $data['lawyerName'] . "</option>";
    }
    ?>
</select>

            <td><button class='button'><span>Save</span></button></td>
        </tr>
    </table>
    </form>
            </div>
</fieldset>
<!-- Bahagian Form (HTML) Tamat -------------------- -->
<!-- Bahagian Insert data (PHP) mula --------------- -->
<?PHP 
// Menyemak data POST
if(!empty($_POST))
{   
    // Mengambil data POST
  
    $paralegalID=$_POST['paralegalID'];
    $paralegalName=$_POST['paralegalName'];
    $clientID=$_POST['clientID'];
    $lawyerID=$_POST['lawyerID'];

    //------------- data validation ---------------------------------------------------------
        //Data validation bagi no kad pengenalan bilangan digit & wujud aksara
 
            // SQL query to check if the caseID exists in the database
    $sqlcheckparalegalID = "SELECT * FROM paralegals WHERE paralegalID = '$paralegalID'";
    $result = mysqli_query($condb, $sqlcheckparalegalID);

    if (mysqli_num_rows($result) > 0) {
        // Case ID already exists in the database
        echo "Paralegal ID '$paralegalID' already exists in the database.";
    } else {
        // Case ID doesn't exist in the database
        echo "paralegal ID '$paralegalID' is available and can be registered.";
    }
    //------------- Data validation ---------------------------------------------------------
    
    //Memasukkan data ke dalam jadual ahli
    if(mysqli_query($condb,"insert into paralegals
    (paralegalID, paralegalName, clientID, lawyerID) 
    VALUES ('$paralegalID', '$paralegalName', '$clientID', '$lawyerID')"))
    {
        echo"<script>alert('Pendaftaran berjaya');</script>";
    }
    else
    {
        echo"<script>alert('Pendaftaran Gagal');window.history.back();</script>";
    }
}
?>
<!-- Bahagian Insert data (PHP) tamat --------------- -->

<nav class="navigation">
        <a href="../index.php" class="nav-link">Home</a>
        <a href="createClientsDetails.php" class="nav-link">Create Clients</a>
        <a href="updateLawyersDetails.php" class="nav-link">Manage Lawyers</a>
        <a href="updateParalegalDetails.php" class="nav-link">Manage Paralegals</a>
        <a href="createAdminDetails.php" class="nav-link">Create Admins</a>
        <a href="updateAdminDetails.php" class="nav-link">Manage Admins</a>
    </nav>

<!-- Bahagian papar data (HTML in PHP) tamat ------------- -->
<?PHP
include('footer.php');
?>