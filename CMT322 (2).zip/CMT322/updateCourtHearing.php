<!--Menghubungkan fail dengan connection dan header file-->
<?PHP
include('header.php');
include('connection.php');
?>
<!--Mengisytiharkan pembolehubah css-->

<!--Kawasan form HTML bermula-->
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
<div class="w3-container">
<title>Court Hearing Details</title>
  <div class="w3-panel w3-padding-small w3-pale-green w3-bottombar w3-round-xlarge w3-topbar w3-border-green w3-border">
<p id='para1'>Court Hearing List</p>
</div>
</div>
<!-- Bahagian Form (HTML) Tamat -------------------- -->
<!-- Bahagian Insert data (PHP) mula --------------- -->
<!-- Bahagian Insert data (PHP) tamat --------------- -->

<!-- Bahagian papar data (HTML in PHP) mula ------------- -->
<br>
<fieldset style="width:100%">
<div class="w3-panel">
<p id='para2'>Court Hearing Details</p>
<div>

<?PHP 
// Menyemak data POST
if(!empty($_POST))
{   
    // Mengambil data POST
    $HearingID = $_POST['HearingID'];
    $caseID=$_POST['caseID'];
    $lawyerID=$_POST['lawyerID'];
    $clientID=$_POST['clientID'];
    $dateHearing = $_POST['dateHearing'];
    $HearingTime=$_POST['HearingTime'];
    $HearingType=$_POST['HearingType'];
    $CourtRoom=$_POST['CourtRoom'];
    $Notes=$_POST['Notes'];
}
?>

<?PHP 
// Lakukan query terhadap pangkalan data
$sqlselect = mysqli_query($condb, "SELECT
ch.HearingID,
c.clientsName,
cd.caseType AS clientsCase, -- Use caseType instead of clientsCase
cd.caseDescription,
l.lawyerName,
ch.dateHearing,
ch.HearingTime,
ch.HearingType,
ch.CourtRoom,
ch.Notes
FROM courthearing ch
JOIN clients c ON ch.clientID = c.clientID
JOIN case_details cd ON ch.caseID = cd.caseID
JOIN lawyers l ON ch.lawyerID = l.lawyerID;

");
echo"<table border='1' width='100%'>";
echo "<thead style='background-color: #1E384E; color: #FFFFFF;'>";
echo "<tr>";
echo "<th width='5%'>No</th>";
echo "<th width='15%'>Hearing ID</th>";
echo "<th width='15%'>Client Name</th>";
echo "<th width='15%'>Client Case</th>";
echo "<th width='15%'>Client Case Description</th>";
echo "<th width='10%'>Lawyer Name</th>";
echo "<th width='10%'>Date Hearing</th>";
echo "<th width='10%'>Hearing Time</th>"; 
echo "<th width='10%'>Hearing Type</th>"; 
echo "<th width='10%'>Court Room</th>"; 
echo "<th width='10%'>Notes</th>"; 
echo "<th width='10%'>Update</th>";
echo "<th width='10%'>Delete</th>";
echo "</tr>";
echo "</thead>";
echo "<tbody>";


    $pembilang = 1;
    while ($row = mysqli_fetch_array($sqlselect)) {
        $bgColor = ($pembilang % 2 === 0) ? "#93ABB7" : "#FFFFFF";
    // Set the text color for odd rows
    $textColor = ($pembilang % 2 === 0) ? "#1E384E" : "#000000";
   
    echo "<tr style='background-color: " . $bgColor . "; color: " . $textColor . ";'>";
    echo "<td align='center'>" . $pembilang . "</td>";
    echo "<td>" . htmlspecialchars($row['HearingID']) . "</td>";
    echo "<td>" . htmlspecialchars($row['clientsName']) . "</td>";
    echo "<td>" . htmlspecialchars($row['clientsCase']) . "</td>";
    echo "<td>" . htmlspecialchars($row['caseDescription']) . "</td>";
    echo "<td>" . htmlspecialchars($row['lawyerName']) . "</td>";
    echo "<td>" . htmlspecialchars($row['dateHearing']) . "</td>";
    echo "<td>" . htmlspecialchars($row['HearingTime']) . "</td>";
    echo "<td>" . htmlspecialchars($row['HearingType']) . "</td>";
    echo "<td>" . htmlspecialchars($row['CourtRoom']) . "</td>";
    echo "<td>" . htmlspecialchars($row['Notes']) . "</td>";
    echo "<td align='center'><a href='courtHearingUpdate.php?HearingID=" . $row['HearingID'] . "'>Update</a></td>";
    echo "<td align='center'><a href='delete.php?HearingID=" . $row['HearingID'] . "' onClick=\"return confirm('Are you sure you want to delete this record?')\">Delete</a></td>";
    echo "</tr>";
        $pembilang++;
}
echo"</table></fieldset><br>";

mysqli_close($condb);
?>
<nav class="navigation">
    <a href="../index.php" class="nav-link">Home</a>
    <a href="createClientAlert.php" class="nav-link">Create Client Alert</a>
    <a href="updateClientAlert.php" class="nav-link">Manage Client Alert</a>
    <a href="updateClientAlert.php" class="nav-link">Create Court Hearing</a>
</nav>
<!-- Bahagian papar data (HTML in PHP) tamat ------------- -->
<?PHP
include('footer.php');
?>