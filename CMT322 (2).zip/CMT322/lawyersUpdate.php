<?PHP 
include('header.php'); 
?>
<link rel="stylesheet" type="text/css" href="style.css">
<!-- (PHP) bahagaian mengambil data mula ---------------------------------------- -->
<?PHP
//L1 : Memanggil fail connection.php
include('connection.php');

//L2 : Mengambil data GET
$lawyerID=$_GET['lawyerID'];

//L3 : Mencari data dipangkalan data
$sqlcari=mysqli_query($condb,"select* from lawyers where lawyerID='$lawyerID'");

//L4 : Mengambil data yang di cari di L3
$data=mysqli_fetch_array($sqlcari);

?>
<!-- (PHP) bahagaian mengambil data tamat -------------------------------------- -->

<!-- (html + PHP) bahagian form yang mempunyai data mula ----------------------- -->

<!-- // L5 : Menyediakan borang dan memaparkan data yang di L4-->
<div class="form-container">
<form action='lawyersUpdate.php' method='POST'>
<fieldset style="width:85%">
    <p id="para2">Update below information</p>
    <div class="contact-form-group">
            <input class="contact-form-input" type="text" id="lawyerName" name="lawyerName" value="<?PHP echo $data['lawyerName'];?>" required>
            <label class="contact-form-label" for="lawyerName">Lawyer Name:</label>
        </div>
    
    <div>
        <input type="hidden" id="lawyerID" name="lawyerID" placeholder="Must be exactly 10 integer" value="<?PHP echo $data['lawyerID'];?>" required>
    </div>
    
    <tr><tr><td align='center'>
	<tr>
    <td align='right'>Case ID :</td>
    <td>
        <select name='caseID' required>
            <option disabled selected value> -- Select Case ID -- </option>
            <?php 
            $sqlCaseType = mysqli_query($condb, "SELECT DISTINCT caseID, caseDescription FROM case_details");
            while($row = mysqli_fetch_array($sqlCaseType)) {
                $selected = ($data['caseID'] == $row['caseID']) ? 'selected' : '';
                echo "<option value='".$row['caseID']."' $selected>".$row['caseID']." - " . $row['caseDescription'] . "</option>";
            }
            ?>
        </select>
    </td>
    <td align='right'>Client ID :</td>
    <td>
        <select name='clientID' required>
            <option disabled selected value> -- Select Client ID -- </option>
            <?php 
            $sqlCaseType = mysqli_query($condb, "SELECT DISTINCT clientID, clientsName FROM clients");
            while($row = mysqli_fetch_array($sqlCaseType)) {
                $selected = ($data['clientID'] == $row['clientID']) ? 'selected' : '';
                echo "<option value='".$row['clientID']."' $selected>".$row['clientID']." - " . $row['clientsName'] . "</option>";
            }
            ?>
        </select>
    </td>
</tr>
	</tr></tr>
    <tr>
        <td></td>
        <td><input type='submit' class='button' value='Update'></td>
    </tr>
</form>
        </div>
<!-- (html + PHP) bahagian form yang mempunyai data tamat ---------------------- -->


<!-- (PHP) bahagian mengemaskini data mula ------------------------------------- -->
<?PHP

//Langkah 6 : Menguju kewujudan data POST
if(!empty($_POST))
{
  # L2 : mengambil data POST
  $lawyerID = mysqli_real_escape_string($condb, $_POST['lawyerID']);
    $lawyerName = mysqli_real_escape_string($condb, $_POST['lawyerName']);
    $caseID = mysqli_real_escape_string($condb, $_POST['caseID']);
    $clientID = mysqli_real_escape_string($condb, $_POST['clientID']);

     
    //Langkah 9 : data validation

    //Langkah 9.1 : Menguji format NoKP
     
    //Langkah 9.2 : Mengelakkan dari pengguna meng disable kan akaun sendiri
  
    
    //Langkah 10 : Melaksanakan proses mengemaskini data
    $updateQuery = "UPDATE lawyers SET  
                lawyerName='$lawyerName',
                caseID='$caseID',
                clientID='$clientID' 
                WHERE lawyerID='$lawyerID'";

    if(mysqli_query($condb, $updateQuery))
    {
        // langkah 10.1 : Jika berjaya, papar msg dan kembali ke fail pengguna_senarai.php
        echo "<script>alert('Kemaskini berjaya.'); 
        window.location.href='updateLawyersDetails.php';</script>";
    }
    else
    {
        // Langkah 10.2 : Jika Gagal, Papar msg dan kembali ke previous page
        echo "<script>alert('Kemaskini tidak berjaya.'); 
        window.history.back();
        </script>";
    }  

mysqli_close($condb);
}

?>
<!-- (PHP) bahagian mengemaskini data tamat ------------------------------------ -->
<nav class="navigation">
        <a href="../index.php" class="nav-link">Home</a>
        <a href="createClientsDetails.php" class="nav-link">Create Clients</a>
        <a href="updateClientsDetails.php" class="nav-link">Manage Clients</a>
        <a href="createLawyerDetails.php" class="nav-link">Create Lawyer</a>
        <a href="createClientsDetails.php" class="nav-link">Create Paralegals</a>
        <a href="updateParalegalDetails.php" class="nav-link">Manage Paralegals</a>
        <a href="createAdminDetails.php" class="nav-link">Create Admins</a>
        <a href="updateAdminDetails.php" class="nav-link">Manage Admins</a>
    </nav>
<?PHP 
include('footer.php'); 
?>