<?PHP 
include('header.php'); 
?>
<link rel="stylesheet" type="text/css" href="style.css">
<!-- (PHP) bahagaian mengambil data mula ---------------------------------------- -->
<?PHP
//L1 : Memanggil fail connection.php
include('connection.php');

//L2 : Mengambil data GET
$paralegalID=$_GET['paralegalID'];

//L3 : Mencari data dipangkalan data
$sqlcari=mysqli_query($condb,"select* from paralegals where paralegalID='$paralegalID'");

//L4 : Mengambil data yang di cari di L3
$data=mysqli_fetch_array($sqlcari);

?>
<!-- (PHP) bahagaian mengambil data tamat -------------------------------------- -->

<!-- (html + PHP) bahagian form yang mempunyai data mula ----------------------- -->

<!-- // L5 : Menyediakan borang dan memaparkan data yang di L4-->
<div class="form-container">
<form action='paralegalUpdate.php' method='POST'>
<fieldset style="width:85%">
<p id="para2">Update below information</p>
    <div class="contact-form-group">
            <input class="contact-form-input" type="text" id="paralegalName" name="paralegalName" value="<?PHP echo $data['paralegalName'];?>" required>
            <label class="contact-form-label" for="paralegalName">Paralegal Name:</label>
        </div>
    <div>
        <input type="hidden" id="paralegalID" name="paralegalID" placeholder="Must be exactly 10 integer" value="<?PHP echo $data['paralegalID'];?>" required>
    </div>
    <td>
    <select name='clientID' required>
    <option disabled selected value>-- Select Client ID --</option>
    <?PHP 
    $sqlclient = mysqli_query($condb, "SELECT DISTINCT clientID, clientsName from clients");
    while ($data = mysqli_fetch_array($sqlclient)) {
        echo "<option value='" . $data['clientID'] . "'>" . $data['clientID'] ." - " . $data['clientsName'] . "</option>";
    }
    ?>
</select>
            </td> 
            <td>     
            <select name='lawyerID' required>
    <option disabled selected value> -- Select Lawyer ID -- </option>
    <?php 
    $sqlLawyers = mysqli_query($condb, "SELECT DISTINCT lawyerID, lawyerName from lawyers");
    while ($data = mysqli_fetch_array($sqlLawyers)) {
        echo "<option value='" . $data['lawyerID'] . "'>" . $data['lawyerID'] ." - " . $data['lawyerName'] . "</option>";
    }
    ?>
</select>
<td>

	</tr></tr>
    <tr>
        <td></td>
        <td><input type='submit' class='button' value='Kemaskini'></td>
    </tr>
</form>
        </div>
<!-- (html + PHP) bahagian form yang mempunyai data tamat ---------------------- -->


<!-- (PHP) bahagian mengemaskini data mula ------------------------------------- -->
<?PHP

//Langkah 6 : Menguju kewujudan data POST
if(!empty($_POST))
{
  # L2 : mengambil data POST
  $paralegalID=$_POST['paralegalID'];
    $paralegalName=$_POST['paralegalName'];
    $clientID=$_POST['clientID'];
    $lawyerID=$_POST['lawyerID'];
     
    //Langkah 9 : data validation

    //Langkah 9.1 : Menguji format NoKP
     
    //Langkah 9.2 : Mengelakkan dari pengguna meng disable kan akaun sendiri
  
    
    //Langkah 10 : Melaksanakan proses mengemaskini data
    $updateQuery = "UPDATE paralegals SET  
                paralegalName='$paralegalName',
                clientID='$clientID',
                lawyerID='$lawyerID'
                WHERE paralegalID='$paralegalID'";

    if(mysqli_query($condb, $updateQuery))
    {
        // langkah 10.1 : Jika berjaya, papar msg dan kembali ke fail pengguna_senarai.php
        echo "<script>alert('Kemaskini berjaya.'); 
        window.location.href='updateParalegalDetails.php';</script>";
    }
    else
    {
        // Langkah 10.2 : Jika Gagal, Papar msg dan kembali ke previous page
        echo "<script>alert('Kemaskini tidak berjaya.'); 
        window.history.back();
        </script>";
    }  

mysqli_close($condb);
}

?>
<!-- (PHP) bahagian mengemaskini data tamat ------------------------------------ -->
<nav class="navigation">
        <a href="../index.php" class="nav-link">Home</a>
        <a href="createClientsDetails.php" class="nav-link">Create Clients</a>
        <a href="updateClientsDetails.php" class="nav-link">Manage Clients</a>
        <a href="createLawyerDetails.php" class="nav-link">Create Lawyer</a>
        <a href="updateLawyerDetails.php" class="nav-link">Manage Lawyer</a>
        <a href="createClientsDetails.php" class="nav-link">Create Paralegals</a>
        <a href="createAdminDetails.php" class="nav-link">Create Admins</a>
        <a href="updateAdminDetails.php" class="nav-link">Manage Admins</a>
    </nav>
<?PHP 
include('footer.php'); 
?>