<!--Menghubungkan fail dengan connection dan header file-->
<?PHP
include('header.php');
include('connection.php');
?>
<!--Kawasan form HTML bermula-->
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
 <link rel="stylesheet" type="text/css" href="style.css">
<div class="w3-container">
  <div class="w3-panel w3-padding-small w3-pale-green w3-bottombar w3-round-xlarge w3-topbar w3-border-green w3-border">
<p id='para1'>Court Hearing Details</p>
</div>
</div>
<fieldset style="width:100%">
<div class="w3-panel w3-pale-brown w3-leftbar w3-rightbar w3-border-blu">

    <p id='para2'>Fill in the information of the court hearing</p>
</div>
<div class="form-container">
    <form action='' method='POST'>
    <table>
        <tr>

        <div class="w3-bar">
</div>
        </tr>
        <tr>
        <div class="contact-form-group">
            <input class="contact-form-input" type="text" id="HearingID" name="HearingID" required placeholder="Please insert exactly 5 digits">
            <label class="contact-form-label" for="HearingID">Hearing ID:</label>
        </div>
        <td>
    <select name='caseID' required>
        <option disabled selected value> -- Select Case ID -- </option>
        <?php 
        $sqlCaseDetails = mysqli_query($condb, "SELECT caseID, caseType from case_details");
        while ($case = mysqli_fetch_array($sqlCaseDetails)) {
            echo "<option value='" . $case['caseID'] . "'>" . $case['caseID'] . " - " . $case['caseType'] . "</option>";
        }
        ?>
    </select>
</td>
<td>
    <select name='lawyerID' required>
        <option disabled selected value> -- Select Lawyer ID -- </option>
        <?php 
        $sqlLawyerDetails = mysqli_query($condb, "SELECT lawyerID, lawyerName from lawyers");
        while ($lawyer = mysqli_fetch_array($sqlLawyerDetails)) {
            echo "<option value='" . $lawyer['lawyerID'] . "'>" . $lawyer['lawyerID'] . " - " . $lawyer['lawyerName'] . "</option>";
        }
        ?>
    </select>
</td>
<td>
    <select name='clientID' required>
        <option disabled selected value> -- Select Client ID -- </option>
        <?php 
        $sqlClientDetails = mysqli_query($condb, "SELECT clientID, clientsName from clients");
        while ($client = mysqli_fetch_array($sqlClientDetails)) {
            echo "<option value='" . $client['clientID'] . "'>" . $client['clientID'] . " - " . $client['clientsName'] . "</option>";
        }
        ?>
    </select>
</td>      
            <div>
        <label for="dateHearing"> Date Hearing:</label>
        <input type="date" id="dateHearing" name="dateHearing" required>
    </div>            
    <div>
        <label for="HearingTime">Hearing Time:</label>
        <input type="time" id="HearingTime" name="HearingTime" required>
    </div>
    <td>
    <select name='HearingType' required>
    <option disabled selected value> -- Select Hearing Type -- </option>
    <?php 
    $sqlHearingTypeDetails = mysqli_query($condb, "SELECT HearingType from courthearing");
    while ($case = mysqli_fetch_array($sqlHearingTypeDetails)) {
        echo "<option value='" . $case['HearingType'] . "'>" . $case['HearingType'] . "</option>";
    }
    ?>
</select>
</td>
<div class="contact-form-group">
            <input class="contact-form-input" type="text" id="CourtRoom" name="CourtRoom" required placeholder="Please insert exactly 5 digits">
            <label class="contact-form-label" for="CourtRoom">Court Room:</label>
        </div>
        <div class="contact-form-group">
            <input class="contact-form-input" type="text" id="Notes" name="Notes" required placeholder="Please insert exactly 5 digits">
            <label class="contact-form-label" for="Notes">Notes:</label>
        </div>
            <td><button class='button'<span>Save</span></button></td>
        </tr>
    </table>
    </form>
            </div>
</fieldset>
<!-- Bahagian Form (HTML) Tamat -------------------- -->
<!-- Bahagian Insert data (PHP) mula --------------- -->
<?PHP 
// Menyemak data POST
// Check if POST data is not empty
if (!empty($_POST)) {
    // Retrieve data from POST
    $HearingID = mysqli_real_escape_string($condb, $_POST['HearingID']);
    $caseID = mysqli_real_escape_string($condb, $_POST['caseID']);
    $lawyerID = mysqli_real_escape_string($condb, $_POST['lawyerID']);
    $clientID = mysqli_real_escape_string($condb, $_POST['clientID']);
    $dateHearing = mysqli_real_escape_string($condb, $_POST['dateHearing']);
    $HearingTime = mysqli_real_escape_string($condb, $_POST['HearingTime']);
    $HearingType = mysqli_real_escape_string($condb, $_POST['HearingType']);
    $CourtRoom = mysqli_real_escape_string($condb, $_POST['CourtRoom']);
    $Notes = mysqli_real_escape_string($condb, $_POST['Notes']);
    // SQL query to check if the clientID exists in the database
    // Check if caseID exists in case_details table
$sqlCheckHearingID = "SELECT * FROM courthearing WHERE HearingID = '$HearingID'";
$resultCaseID = mysqli_query($condb, $sqlCheckHearingID);

    // The caseID exists, proceed with insertion into clients table
    $sqlInsertCourtHearing = "INSERT INTO courthearing (HearingID, caseID, lawyerID, clientID, dateHearing, HearingTime, HearingType, CourtRoom, Notes) 
    VALUES 
    ('$HearingID', '$caseID', '$lawyerID', '$clientID', '$dateHearing', '$HearingTime', '$HearingType', '$CourtRoom', '$Notes')";
    if (mysqli_query($condb, $sqlInsertCourtHearing)) {
        echo "<script>alert('Registration successful.');</script>";
    } else {
        echo "<script>alert('Registration failed: " . mysqli_error($condb) . "'); window.history.back();</script>";
    }

}

?>
<!-- Bahagian Insert data (PHP) tamat --------------- -->

<nav class="navigation">
        <a href="../index.php" class="nav-link">Home</a>
        <a href="createClientAlert.php" class="nav-link">Create Client Alert</a>
        <a href="updateClientAlert.php" class="nav-link">Manage Client Alert</a>
        <a href="updateCourtHearing.php" class="nav-link">Manage Court Hearing</a>
    </nav>

<!-- Bahagian papar data (HTML in PHP) tamat ------------- -->
<?PHP
include('footer.php');
?>