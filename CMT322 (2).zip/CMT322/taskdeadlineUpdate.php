<?PHP 
include('header.php'); 
?>
<link rel="stylesheet" type="text/css" href="style.css">
<!-- (PHP) bahagaian mengambil data mula ---------------------------------------- -->
<?PHP
//L1 : Memanggil fail connection.php
include('connection.php');

//L2 : Mengambil data GET
$taskID=$_GET['taskID'];

//L3 : Mencari data dipangkalan data
$sqlcari=mysqli_query($condb,"select* from taskdeadline where taskID='$taskID'");

//L4 : Mengambil data yang di cari di L3
$data=mysqli_fetch_array($sqlcari);

?>
<!-- (PHP) bahagaian mengambil data tamat -------------------------------------- -->

<!-- (html + PHP) bahagian form yang mempunyai data mula ----------------------- -->

<!-- // L5 : Menyediakan borang dan memaparkan data yang di L4-->
<div>
<div class="w3-panel w3-pale-brown w3-leftbar w3-rightbar w3-border-blu">
<p id='para2'>Update below information</p>
</div>
<div class="form-container">
<form action='taskdeadlineUpdate.php' method='POST' lass="contact-form">
<table>
<tr>
<div class="contact-form-group">
    <label class="contact-form-label" for="taskdeadline">Task Deadline:</label>
    <input class="contact-form-input" type="date" id="taskdeadline" name="taskdeadline" value="<?php echo $data['taskdeadline']; ?>" required>   
</div>
    <div>
        <input type="hidden" id="taskID" name="taskID" placeholder="Must be exactly 10 integer" value="<?PHP echo $data['taskID'];?>" required>
    </div>
    <td>
    <select name='status' required>
    <option disabled selected value> -- Select Task Status -- </option>
    <?php 
    $sqlCaseDetails = mysqli_query($condb, "SELECT status from taskdeadline");
    while ($case = mysqli_fetch_array($sqlCaseDetails)) {
        echo "<option value='" . $case['status'] . "'>" . $case['status'] . "</option>";
    }
    ?>
</select>
</td>
<td>
        <select name='priority' required>
        <option disabled selected value> -- Select Task Priority -- </option>
        <?php 
        $sqlCaseDetails = mysqli_query($condb, "SELECT priority from taskdeadline");
        while ($case = mysqli_fetch_array($sqlCaseDetails)) {
            echo "<option value='" . $case['priority'] . "'>" . $case['priority'] . "</option>";
        }
        ?>
        </select>
        </td> 
    </td>
        </td>
        <td><input type='submit' class='button' value='Update'></td>
    </tr>

</table>
</form>
        </div>
    </div>
<!-- (html + PHP) bahagian form yang mempunyai data tamat ---------------------- -->


<!-- (PHP) bahagian mengemaskini data mula ------------------------------------- -->
<?PHP

//Langkah 6 : Menguju kewujudan data POST
if(!empty($_POST))
{
  # L2 : mengambil data POST
  $taskID = mysqli_real_escape_string($condb, $_POST['taskID']);
    $taskdeadline = mysqli_real_escape_string($condb, $_POST['taskdeadline']);
    $status = mysqli_real_escape_string($condb, $_POST['status']);
    $priority = mysqli_real_escape_string($condb, $_POST['priority']);

     
    //Langkah 9 : data validation

    //Langkah 9.1 : Menguji format NoKP
     
    //Langkah 9.2 : Mengelakkan dari pengguna meng disable kan akaun sendiri
  
    
    //Langkah 10 : Melaksanakan proses mengemaskini data
    $updateQuery = "UPDATE taskdeadline SET  
                taskdeadline='$taskdeadline',
                status='$status',
                priority='$priority' 
                WHERE taskID='$taskID'";

    if(mysqli_query($condb, $updateQuery))
    {
        // langkah 10.1 : Jika berjaya, papar msg dan kembali ke fail pengguna_senarai.php
        echo "<script>alert('Kemaskini berjaya.'); 
        window.location.href='updateTaskDeadline.php';</script>";
    }
    else
    {
        // Langkah 10.2 : Jika Gagal, Papar msg dan kembali ke previous page
        echo "<script>alert('Kemaskini tidak berjaya.'); 
        window.history.back();
        </script>";
    }  

mysqli_close($condb);
}

?>
<!-- (PHP) bahagian mengemaskini data tamat ------------------------------------ -->
<nav class="navigation">
        <a href="../index.php" class="nav-link">Home</a>
        <a href="createTaskDetails.php" class="naveate Task</a>-link">Create Task</a>
        <a href="updateTaskDetails.php" class="nav-link">Manage Task</a>
        <a href="createTaskDeadline.php" class="nav-link">Create Deadline</a>
        
    </nav>
<?PHP 
include('footer.php'); 
?>