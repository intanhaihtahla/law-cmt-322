<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Court Order</title>
    <meta name="description" content="Award Winning Family Lawyers">
    <link rel="icon" href="/favicon.ico">
    <link rel="stylesheet" href="style.css">
</head>
</td>
    </tr>
    <img src="img/footer.jpg" alt="Footer Image" class="footer-image">
    <!--row footer -->
    <div>
    <tr>
<div class="footer-text-container">
<svg width="53" height="55" viewBox="0 0 53 55" fill="none" xmlns="http://www.w3.org/2000/svg">
<mask id="mask0_8_102" style="mask-type:luminance" maskUnits="userSpaceOnUse" x="0" y="0" width="53" height="55">
<path d="M26.5 51C38.9264 51 49 40.4787 49 27.5C49 14.5213 38.9264 4 26.5 4C14.0736 4 4 14.5213 4 27.5C4 40.4787 14.0736 51 26.5 51Z" fill="#555555" stroke="white" stroke-width="6.75" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M35.5 20.0013C34.4897 17.851 31.4579 14.0898 25.3941 14.6268C19.3304 15.165 14.782 21.0776 15.2882 28.6011C15.7945 36.1258 21.352 40.4251 26.4044 40.4251C32.4681 40.4251 35.5 35.2657 35.5 35.2657" stroke="white" stroke-width="6.75" stroke-linecap="round" stroke-linejoin="round"/>
</mask>
<g mask="url(#mask0_8_102)">
<path d="M-0.500015 -0.700195H53.5V55.6998H-0.500015V-0.700195Z" fill="#93ABB7"/>
</g>
</svg>
    <p>2023 Court Order. All rights reserved.</p>
  </div>
    </tr>
</div>

</table>
</body> 
</html>
