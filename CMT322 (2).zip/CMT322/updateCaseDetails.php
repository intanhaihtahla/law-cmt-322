<!--Menghubungkan fail dengan connection dan header file-->
<?PHP
include('header.php');
include('connection.php');
?>
<!--Mengisytiharkan pembolehubah css-->

<!--Kawasan form HTML bermula-->
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
<div class="w3-container">
  <div class="w3-panel w3-padding-small w3-pale-green w3-bottombar w3-round-xlarge w3-topbar w3-border-green w3-border">
<p id='para1'>List of Registered Case Details</p>
</div>
</div>
<br>
<fieldset style="width:100%">
<div class="w3-panel ">
<p id='para2'>Case Details</p>
<div>

<?PHP 
// Menyemak data POST
if(!empty($_POST))
{   
    // Mengambil data POST
    $caseID = $_POST['caseID'];
    $caseType=$_POST['caseType'];
    $caseDesc=$_POST['caseDescription'];
    $caseStatus=$_POST['caseStatus'];
    $clientName=$_POST['clientName'];
    $clientContact=$_POST['clientContactInformation'];
    $dateCreated=$_POST['dateCreated'];
}
?>

<?PHP 
// Lakukan query terhadap pangkalan data
$sqlselect = mysqli_query($condb, "SELECT * FROM case_details");

// Start the HTML table and define the header row
echo "<table border='1' width='100%'>";
echo "<thead style='background-color: #1E384E; color: #FFFFFF;'>";
echo "<tr>";
echo "<th width='5%'>No</th>";
echo "<th width='20%'>Client Name</th>";
echo "<th width='15%'>Case ID</th>";
echo "<th width='10%'>Case Type</th>";
echo "<th width='10%'>Case Status</th>";
echo "<th width='10%'>Case Description</th>";
echo "<th width='10%'>Client Contact Information</th>";
echo "<th width='10%'>Date Created</th>";
echo "<th width='10%'>Update</th>";
echo "<th width='10%'>Delete</th>";
echo "</tr>";
echo "</thead>";
echo "<tbody>";

// Initialize a counter for the row numbers
$pembilang = 1;

// Loop through each row from the result of the SQL query
while ($row = mysqli_fetch_array($sqlselect)) {
    // Set the background color for odd rows
    $bgColor = ($pembilang % 2 === 0) ? "#93ABB7" : "#FFFFFF";
    // Set the text color for odd rows
    $textColor = ($pembilang % 2 === 0) ? "#1E384E" : "#000000";

    // Output the data of each row
    echo "<tr style='background-color: " . $bgColor . "; color: " . $textColor . ";'>";
    echo "<td align='center'>" . $pembilang . "</td>";
    echo "<td>" . htmlspecialchars($row['clientName']) . "</td>";
    echo "<td>" . htmlspecialchars($row['caseID']) . "</td>";
    echo "<td>" . htmlspecialchars($row['caseType']) . "</td>";
    echo "<td>" . htmlspecialchars($row['caseStatus']) . "</td>";
    echo "<td>" . htmlspecialchars($row['caseDescription']) . "</td>";
    echo "<td>" . htmlspecialchars($row['clientContactInformation']) . "</td>";
    echo "<td>" . htmlspecialchars($row['dateCreated']) . "</td>";
    echo "<td align='center'><a href='caseUpdate.php?caseID=" . $row['caseID'] . "'>Update</a></td>";
    echo "<td align='center'><a href='delete.php?caseID=" . $row['caseID'] . "' onClick=\"return confirm('Are you sure you want to delete this record?')\">Delete</a></td>";
    echo "</tr>";

    // Increment the counter
    $pembilang++;
}

// Close the table's body and the table itself
echo "</tbody>";
echo "</table>";
echo "</fieldset><br>";


mysqli_close($condb);
?>
<nav class="navigation">
    <a href="../index.php" class="nav-link">Home</a>
    <a href="createCaseDetails.php" class="nav-link">Create Case</a>
</nav>
<!-- Bahagian papar data (HTML in PHP) tamat ------------- -->
<?PHP
include('footer.php');
?>