<!--Menghubungkan fail dengan connection dan header file-->
<?PHP
include('header.php');
include('connection.php');
?>
<!--Kawasan form HTML bermula-->
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
 <link rel="stylesheet" type="text/css" href="style.css">
<div class="w3-container">
  <div class="w3-panel w3-padding-small w3-pale-green w3-bottombar w3-round-xlarge w3-topbar w3-border-green w3-border">
<p id='para1'>Task Deadline</p>
</div>
</div>
<fieldset style="width:100%">
<div class="w3-panel w3-pale-brown w3-leftbar w3-rightbar w3-border-blu">

    <p id='para2'>Fill in the information of the task</p>
</div>
<div class="form-container">
    <form action='' method='POST'>
    <table>
        <tr>

        <div class="w3-bar">
</div>
        </tr>
        <tr>
        <select name='taskID' required>
        <option disabled selected value> -- Select Task ID -- </option>
        <?php 
        $sqlTaskIDs = "SELECT taskID, taskname FROM `task management`";
        $resultTaskIDs = mysqli_query($condb, $sqlTaskIDs);

        while ($case = mysqli_fetch_array($resultTaskIDs)) {
            echo "<option value='" . $case['taskID'] . "'>" . $case['taskID'] . " - " . $case['taskname'] . "</option>";
        }
        ?>
        </select>
    <div>
        <label for="taskdeadline">Task Deadline:</label>
        <input type="date" id="taskdeadline" name="taskdeadline" placeholder="Task Deadline" required>
    </div>
    
    <td>

    <select name='status' required>
    <option disabled selected value> -- Select Task Status -- </option>
    <?php 
    $sqlCaseDetails = mysqli_query($condb, "SELECT status from taskdeadline");
    while ($case = mysqli_fetch_array($sqlCaseDetails)) {
        echo "<option value='" . $case['status'] . "'>" . $case['status'] . "</option>";
    }
    ?>
</select>
</select>
</td><td>
        <select name='priority' required>
        <option disabled selected value> -- Select Task Priority -- </option>
        <?php 
        $sqlCaseDetails = mysqli_query($condb, "SELECT priority from taskdeadline");
        while ($case = mysqli_fetch_array($sqlCaseDetails)) {
            echo "<option value='" . $case['priority'] . "'>" . $case['priority'] . "</option>";
        }
        ?>
        </select>


        </td>   
             
            <td><button class='button'><span>Save</span></button></td>
        </tr>
    </table>
    </form>
            </div>
</fieldset>
<!-- Bahagian Form (HTML) Tamat -------------------- -->
<!-- Bahagian Insert data (PHP) mula --------------- -->
<?PHP 
// Menyemak data POST
// Check if POST data is not empty
if (!empty($_POST)) {
    // Retrieve data from POST
    $taskID = mysqli_real_escape_string($condb, $_POST['taskID']);
    $taskdeadline = mysqli_real_escape_string($condb, $_POST['taskdeadline']);
    $status = mysqli_real_escape_string($condb, $_POST['status']);
    $priority = mysqli_real_escape_string($condb, $_POST['priority']);

    // SQL query to check if the clientID exists in the database
    // Check if caseID exists in case_details table
$sqlCheckTaskID = "SELECT * FROM `task management` WHERE taskID = '$taskID'";
$resultCaseID = mysqli_query($condb, $sqlCheckTaskID);

if (mysqli_num_rows($resultCaseID) == 0) {
    // The caseID does not exist in case_details table
    echo "<script>alert('The task ID \"$taskID\" does not exist in the task management table.');</script>";
} else {
    // The caseID exists, proceed with insertion into clients table
    $sqlInsertTaskDeadline = "INSERT INTO taskdeadline (taskID, taskdeadline, status, priority) VALUES ('$taskID', '$taskdeadline', '$status', '$priority')";
if (mysqli_query($condb, $sqlInsertTaskDeadline)) {
    echo "<script>alert('Registration successful.');</script>";
} else {
    echo "<script>alert('Registration failed: " . mysqli_error($condb) . "'); window.history.back();</script>";
}
}

}

?>
<!-- Bahagian Insert data (PHP) tamat --------------- -->

<nav class="navigation">
        <a href="../index.php" class="nav-link">Home</a>
        <a href="createTaskDetails.php" class="nav-link">Create Task</a>
        <a href="updateTaskDetails.php" class="nav-link">Manage Task</a>
        <a href="updateTaskDeadline.php" class="nav-link">Manage Deadline</a>
    </nav>

<!-- Bahagian papar data (HTML in PHP) tamat ------------- -->
<?PHP
include('footer.php');
?>