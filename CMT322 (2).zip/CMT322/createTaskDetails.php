<!--Menghubungkan fail dengan connection dan header file-->
<?PHP
include('header.php');
include('connection.php');
?>
<!--Kawasan form HTML bermula-->
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
 <link rel="stylesheet" type="text/css" href="style.css">
<div class="w3-container">
  <div class="w3-panel w3-padding-small w3-pale-green w3-bottombar w3-round-xlarge w3-topbar w3-border-green w3-border">
<p id='para1'>Task Details</p>
</div>
</div>
<fieldset style="width:100%%">
<div class="w3-panel w3-pale-brown w3-leftbar w3-rightbar w3-border-blu">

    <p id='para2'>Fill in the information of the task</p>
</div>
<div class="form-container">
    <form action='' method='POST' lass="contact-form">
    <table>
        <tr>

        <div class="w3-bar">
</div>
        </tr>
        <tr>
        <div class="contact-form-group">
            <input class="contact-form-input" type="text" id="taskID" name="taskID" required placeholder="Please insert exactly 10 digits">
            <label class="contact-form-label" for="taskID">Task ID:</label>
        </div>
        <div class="contact-form-group">
            <input class="contact-form-input" type="text" id="taskname" name="taskname" required placeholder="Please insert the task name">
            <label class="contact-form-label" for="taskname">Task Name:</label>
        </div>
        <div class="contact-form-group">
            <input class="contact-form-input" type="text" id="taskdetails" name="taskdetails" required placeholder="Please insert the task name">
            <label class="contact-form-label" for="taskdetails">Task Details:</label>
        </div>
    <div>
        <label for="taskdatecreated">Date Created:</label>
        <input type="date" id="taskdatecreated" name="taskdatecreated" placeholder="taskdatecreated" required>
    </div>
    <div>
        <label for="taskduedate">Due Date:</label>
        <input type="date" id="taskduedate" name="taskduedate" placeholder="taskduedate" required>
    </div>
    <td>
    <select name='paralegalID' required>
    <option disabled selected value>--Paralegal ID--</option>
    <?PHP 
    // Adjust the query to also select the name of the paralegal
    $sqlParalegals = mysqli_query($condb, "SELECT paralegalID, paralegalName from paralegals");
    while ($data = mysqli_fetch_array($sqlParalegals)) {
        // Display both the paralegalID and paralegalName in the option text
        echo "<option value='" . $data['paralegalID'] . "'>" . $data['paralegalID'] . " - " . $data['paralegalName'] . "</option>";
    }
    ?>
</select>
           </td>       
           <td>
           <select name='lawyerID' required>
    <option disabled selected value> -- Lawyer ID -- </option>
    <?php 
    // Adjust the query to also select the name of the lawyer
    $sqlLawyers = mysqli_query($condb, "SELECT lawyerID, lawyerName from lawyers");
    while ($data = mysqli_fetch_array($sqlLawyers)) {
        // Display both the lawyerID and lawyerName in the option text
        echo "<option value='" . $data['lawyerID'] . "'>" . $data['lawyerID'] . " - " . $data['lawyerName'] . "</option>";
    }
    ?>
</select>

</td>
<td>
<select name='taskstatus' required>
    <option disabled selected value> --Task Status-- </option>
    <option value='Pending'>Pending</option>
    <option value='In Progress'>In Progress</option>
    <option value='Not Yet'>Not Yet</option>
    <option value='Completed'>Completed</option>
</select>

</td>
            <td><button class='button'><span>Save</span></button></td>
        </tr>
    </table>
    </form>
            </div>
            <nav class="navigation">
        <a href="../index.php" class="nav-link">Home</a>
        <a href="updateTaskDetails.php" class="nav-link">Manage Task</a>
        <a href="createTaskDeadline.php" class="nav-link">Create Deadline</a>
        <a href="updateTaskDeadline.php" class="nav-link">Update Deadline</a>
    </nav>
</fieldset>
<!-- Bahagian Form (HTML) Tamat -------------------- -->
<!-- Bahagian Insert data (PHP) mula --------------- -->
<?PHP 
// Menyemak data POST
if(!empty($_POST))
{   
    // Mengambil data POST
  
    $taskID = $_POST['taskID'];
    $taskname = $_POST['taskname'];
    $taskdetails = $_POST['taskdetails'];
    $paralegalID = $_POST['paralegalID'];
    $lawyerID = $_POST['lawyerID'];
    $taskdatecreated = $_POST['taskdatecreated'];
    $taskduedate = $_POST['taskduedate'];
    $taskstatus = $_POST['taskstatus'];

    //------------- data validation ---------------------------------------------------------
        //Data validation bagi no kad pengenalan bilangan digit & wujud aksara
 
            // SQL query to check if the caseID exists in the database
            $sqlchecktaskID = "SELECT * FROM `task management` WHERE taskID = '$taskID'";
            $result = mysqli_query($condb, $sqlchecktaskID);
            

    if (mysqli_num_rows($result) > 0) {
        // Case ID already exists in the database
        echo "Task ID '$taskID' already exists in the database.";
    } else {
        // Case ID doesn't exist in the database
        echo "Task ID '$taskID' is available and can be registered.";
    }
    //------------- Data validation ---------------------------------------------------------
    
    //Memasukkan data ke dalam jadual ahli
    if(mysqli_query($condb,"insert into `task management`
    (taskID, taskname, taskdetails, paralegalID, lawyerID, taskdatecreated, taskduedate, taskstatus ) 
    VALUES ('$taskID', '$taskname', '$taskdetails', '$paralegalID', 
    '$lawyerID', '$taskdatecreated', '$taskduedate', '$taskstatus')"))
    {
        echo"<script>alert('Pendaftaran berjaya');</script>";
    }
    else
    {
        echo"<script>alert('Pendaftaran Gagal');window.history.back();</script>";
    }
}
?>
<!-- Bahagian Insert data (PHP) tamat --------------- -->



<!-- Bahagian papar data (HTML in PHP) tamat ------------- -->
<?PHP
include('footer.php');
?>