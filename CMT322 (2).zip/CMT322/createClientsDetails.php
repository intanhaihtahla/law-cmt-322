<!--Menghubungkan fail dengan connection dan header file-->
<?PHP
include('header.php');
include('connection.php');
?>
<!--Kawasan form HTML bermula-->
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
 <link rel="stylesheet" type="text/css" href="style.css">
<div class="w3-container">
  <div class="w3-panel w3-padding-small w3-pale-green w3-bottombar w3-round-xlarge w3-topbar w3-border-green w3-border">
<p id='para1'>Client Details</p>
</div>
</div>
<fieldset style="width:85%">
<div class="w3-panel w3-pale-brown w3-leftbar w3-rightbar w3-border-blu">

    <p id='para2'>Fill in the information of the case</p>
</div>
<div class="form-container">
    <form action='' method='POST'>
    <table>
        <tr>

        <div class="w3-bar">
</div>
        </tr>
        <tr>
        <div class="contact-form-group">
            <input class="contact-form-input" type="text" id="clientID" name="clientID" required placeholder="Please insert exactly 10 digits">
            <label class="contact-form-label" for="clientID">Client ID:</label>
        </div>
        <div class="contact-form-group">
            <input class="contact-form-input" type="text" id="clientsName" name="clientsName" required placeholder="Please insert exactly 10 digits">
            <label class="contact-form-label" for="clientsName">Client Name:</label>
        </div>
        <div class="contact-form-group">
            <input class="contact-form-input" type="text" id="clientsCase" name="clientsCase" required placeholder="Please insert exactly 10 digits">
            <label class="contact-form-label" for="clientsCase">Client Case:</label>
        </div>  
    <td>

    <select name='caseID' required>
    <option disabled selected value> -- Select Case ID -- </option>
    <?php 
    $sqlCaseDetails = mysqli_query($condb, "SELECT caseID, caseDescription from case_details");
    while ($case = mysqli_fetch_array($sqlCaseDetails)) {
        echo "<option value='" . $case['caseID'] . "'>" . $case['caseID'] . " - " . $case['caseDescription'] . "</option>";
    }
    ?>
</select>


            </select>
            </td>      
             
            <td><button class='button'<span>Save</span></button></td>
        </tr>
    </table>
    </form>
            </div>
</fieldset>
<!-- Bahagian Form (HTML) Tamat -------------------- -->
<!-- Bahagian Insert data (PHP) mula --------------- -->
<?PHP 
// Menyemak data POST
// Check if POST data is not empty
if (!empty($_POST)) {
    // Retrieve data from POST
    $clientID = mysqli_real_escape_string($condb, $_POST['clientID']);
    $clientsName = mysqli_real_escape_string($condb, $_POST['clientsName']);
    $clientsCase = mysqli_real_escape_string($condb, $_POST['clientsCase']);
    $caseID = mysqli_real_escape_string($condb, $_POST['caseID']);

    // SQL query to check if the clientID exists in the database
    // Check if caseID exists in case_details table
$sqlCheckCaseID = "SELECT * FROM case_details WHERE caseID = '$caseID'";
$resultCaseID = mysqli_query($condb, $sqlCheckCaseID);

if (mysqli_num_rows($resultCaseID) == 0) {
    // The caseID does not exist in case_details table
    echo "<script>alert('The caseID \"$caseID\" does not exist in the case_details table.');</script>";
} else {
    // The caseID exists, proceed with insertion into clients table
    $sqlInsertClient = "INSERT INTO clients (clientID, clientsName, clientsCase, caseID) VALUES ('$clientID', '$clientsName', '$clientsCase', '$caseID')";
    if (mysqli_query($condb, $sqlInsertClient)) {
        echo "<script>alert('Registration successful.');</script>";
    } else {
        echo "<script>alert('Registration failed: " . mysqli_error($condb) . "'); window.history.back();</script>";
    }
}

}

?>
<!-- Bahagian Insert data (PHP) tamat --------------- -->
<nav class="navigation">
        <a href="../index.php" class="nav-link">Home</a>
        <a href="createLawyerDetails.php" class="nav-link">Create Lawyer</a>
        <a href="updateLawyersDetails.php" class="nav-link">Manage Lawyers</a>
        <a href="createClientsDetails.php" class="nav-link">Create Paralegals</a>
        <a href="updateParalegalDetails.php" class="nav-link">Manage Paralegals</a>
        <a href="createAdminDetails.php" class="nav-link">Create Admins</a>
        <a href="updateAdminDetails.php" class="nav-link">Manage Admins</a>
    </nav>


<!-- Bahagian papar data (HTML in PHP) tamat ------------- -->
<?PHP
include('footer.php');
?>