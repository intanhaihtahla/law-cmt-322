<?PHP 
include('header.php'); 
?>
<link rel="stylesheet" type="text/css" href="style.css">
<!-- (PHP) bahagaian mengambil data mula ---------------------------------------- -->
<?PHP
//L1 : Memanggil fail connection.php
include('connection.php');

//L2 : Mengambil data GET
$adminID=$_GET['adminID'];

//L3 : Mencari data dipangkalan data
$sqlcari=mysqli_query($condb,"select* from admin where adminID='$adminID'");

//L4 : Mengambil data yang di cari di L3
$data=mysqli_fetch_array($sqlcari);

?>
<div class="form-container">
<form action='clientUpdate.php' method='POST'>
<fieldset style="width:85%">
<p id="para2">Update below information</p>
<div class="contact-form-group">
            <input class="contact-form-input" type="hidden" id="adminID" name="clientID" required placeholder="Please insert exactly 10 digits">
        </div>
        <div class="contact-form-group">
        <label class="contact-form-label" for="adminName">Admin Name:</label>
            <input class="contact-form-input" type="text" id="adminName" name="adminName" value="<?php echo $data['adminName']; ?>" required> 
            
        </div>
        <div class="contact-form-group">
        <label class="contact-form-label" for="reasonAssignation">Reason Assignation:</label>
            <input class="contact-form-input" type="text" id="reasonAssignation" name="reasonAssignation" value="<?php echo $data['reasonAssignation']; ?>" required> 
            
        </div>
    <td>
    <select name='caseID' required>
    <option disabled selected value> -- Select Case ID -- </option>
    <?php 
    $sqlCaseDetails = mysqli_query($condb, "SELECT caseID, caseDescription from case_details");
    while ($case = mysqli_fetch_array($sqlCaseDetails)) {
        echo "<option value='" . $case['caseID'] . "'>" . $case['caseID'] . " - " . $case['caseDescription'] . "</option>";
    }
    ?>
</select>
            </td>    
            <td>
    <select name='caseID' required>
    <option disabled selected value> -- Select Lawyer ID -- </option>
    <?php 
    $sqlCaseDetails = mysqli_query($condb, "SELECT lawyerID, lawyerName from lawyers");
    while ($case = mysqli_fetch_array($sqlCaseDetails)) {
        echo "<option value='" . $case['lawyerID'] . "'>" . $case['lawyerID'] . " - " . $case['lawyerName'] . "</option>";
    }
    ?>
</select>
            </td>  
        <td><input type='submit' class='button' value='Update'></td>
    </tr>
</form>
        </div>
<!-- (html + PHP) bahagian form yang mempunyai data tamat ---------------------- -->


<!-- (PHP) bahagian mengemaskini data mula ------------------------------------- -->
<?PHP

//Langkah 6 : Menguju kewujudan data POST
if(!empty($_POST))
{
  # L2 : mengambil data POST
  $adminID = mysqli_real_escape_string($condb, $_POST['adminID']);
    $adminName = mysqli_real_escape_string($condb, $_POST['adminName']);
    $caseID = mysqli_real_escape_string($condb, $_POST['caseID']);
    $lawyerID = mysqli_real_escape_string($condb, $_POST['lawyerID']);
    $reasonAssignation = mysqli_real_escape_string($condb, $_POST['reasonAssignation']);

    //Langkah 10 : Melaksanakan proses mengemaskini data
    $updateQuery = "UPDATE admin SET  
                adminName='$adminName',
                caseID='$caseID', 
                lawyerID='$lawyerID',
                reasonAssignation='$reasonAssignation',
                WHERE adminID='$adminID'";

    if(mysqli_query($condb, $updateQuery))
    {
        // langkah 10.1 : Jika berjaya, papar msg dan kembali ke fail pengguna_senarai.php
        echo "<script>alert('Kemaskini berjaya.'); 
        window.location.href='updateAdminDetails.php';</script>";
    }
    else
    {
        // Langkah 10.2 : Jika Gagal, Papar msg dan kembali ke previous page
        echo "<script>alert('Kemaskini tidak berjaya.'); 
        window.history.back();
        </script>";
    }  

mysqli_close($condb);
}

?>
<!-- (PHP) bahagian mengemaskini data tamat ------------------------------------ -->
<nav class="navigation">
        <a href="../index.php" class="nav-link">Home</a>
        <a href="createClientsDetails.php" class="nav-link">Create Clients</a>
        <a href="updateClientsDetails.php" class="nav-link">Manage Clients</a>
        <a href="createLawyerDetails.php" class="nav-link">Create Lawyer</a>
        <a href="updateLawyersDetails.php" class="nav-link">Manage Lawyers</a>
        <a href="createClientsDetails.php" class="nav-link">Create Paralegals</a>
        <a href="updateParalegalDetails.php" class="nav-link">Manage Paralegals</a>
        <a href="createAdminDetails.php" class="nav-link">Create Admins</a>
    </nav>
<?PHP 
include('footer.php'); 
?>