<?php
session_start(); // Ensure you call this at the start to use $_SESSION
?>
<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="style.css">
    <style>
        .header {
            display: flex;
            justify-content: space-between; /* Aligns items on the main axis */
            align-items: center; /* Aligns items on the cross axis */
            background-color: #1E384E;
            padding: 0 10px;
        }
        .logo-container {
            display: flex;
            align-items: center;
        }
        .navigation {
            display: flex;
            justify-content: flex-end;
        }
        .nav-link {
            margin-left: 10px; /* Spacing between links */
            color: #FFFFFF; /* Change color here */
            text-decoration: none; /* Removes underline from links */
            padding: 10px;
            background-color: #6C3483; /* Background color for links */
            border-radius: 5px; /* Rounded corners for links */
        }
        .nav-link:hover {
            background-color: #A569BD; /* Background color for links on hover */
        }
    </style>
</head>
<body>

<header class="header">
    <div class="logo-container">
        <img src="img/logo.jpg" alt="Court Order Logo" class="logo">
        <span class="site-title">Court Order</span>
    </div>
    <?php
    if (isset($_SESSION['userType'])) {
        echo '<nav class="navigation">';
        echo '<a href="index.php" class="nav-link">Home</a>'; // Common link for all users
        
        if ($_SESSION['userType'] === 'admin') {
            echo '<a href="metricDashboard.php" class="nav-link">Dashboard Case</a>';
            echo '<a href="taskMetricDashboard.php" class="nav-link">Task Dashboard</a>';
            echo '<a href="clientAlertDashboard.php" class="nav-link">Important Date Tracking</a>';
            echo '<a href="userDashboard.php" class="nav-link">User Dashboard</a>';
        } elseif ($_SESSION['userType'] === 'lawyer') {
            echo '<a href="metricDashboard.php" class="nav-link">Dashboard Case</a>';
            echo '<a href="taskMetricDashboard.php" class="nav-link">Task Dashboard</a>';
            echo '<a href="clientAlertDashboard.php" class="nav-link">Important Date Tracking</a>';
        } elseif ($_SESSION['userType'] === 'paralegal') {
            echo '<a href="taskMetricDashboard.php" class="nav-link">Task Dashboard</a>';
        }
        echo '</nav>';
    } else {
        echo '<nav class="navigation">';
        echo '<a href="index.php" class="nav-link">Home</a>';
        echo '</nav>';
    }
    ?>
</header>