<?php 
include('header.php'); 
include('connection.php');

// Check if 'caseID' is set in the URL as a GET parameter
if(isset($_GET['caseID'])) {
    $caseID = mysqli_real_escape_string($condb, $_GET['caseID']);

    // Query to get the details of the case
    $sqlcari = mysqli_query($condb, "SELECT * FROM case_details WHERE caseID='$caseID'");

    // Check if the case exists
    if(mysqli_num_rows($sqlcari) > 0) {
        $data = mysqli_fetch_assoc($sqlcari);
    } else {
        // If no record found, redirect or handle the error as needed
        echo "<script>alert('No record found.'); window.history.back();</script>";
        exit;
    }
} else {
    // If 'caseID' is not set, redirect or handle the error
    echo "<script>alert('No caseID provided.'); window.history.back();</script>";
    exit;
}
?>

<!-- (PHP) bahagaian mengambil data tamat -------------------------------------- -->

<!-- (html + PHP) bahagian form yang mempunyai data mula ----------------------- -->

<!-- // L5 : Menyediakan borang dan memaparkan data yang di L4-->
<fieldset style="width:100%">
<div class="w3-panel w3-pale-brown w3-leftbar w3-rightbar w3-border-blu">

<p id='para2'>Update below information</p>
</div>
<div class="form-container">
<form action='caseUpdate.php' method='POST' lass="contact-form">
<table>
    <tr>
    <div class="contact-form-group">
    <label class="contact-form-label" for="caseDescription">Case Description:</label>
    <input class="contact-form-input" type="text" id="caseDescription" name="caseDescription" value="<?php echo $data['caseDescription']; ?>" required>   
</div>
    <div>
        <input type="hidden" id="caseID" name="caseID" placeholder="Must be exactly 10 integer" value="<?PHP echo $data['caseID'];?>" required>
    </div>
    <div class="contact-form-group">
    <label class="contact-form-label" for="clientName">Client Name:</label>
    <input class="contact-form-input" type="text" id="clientName" name="clientName" value="<?php echo $data['clientName']; ?>" required>   
</div>
<div class="contact-form-group">
    <label class="contact-form-label" for="clientContactInformation">Client Contact Information:</label>
    <input class="contact-form-input" type="text" id="clientContactInformation" name="clientContactInformation" value="<?php echo $data['clientContactInformation']; ?>" required>   
</div>
    <div>
    <div>
        <label for="dateCreated">Date Created:</label>
        <input type="date" id="dateCreated" name="dateCreated" value="<?PHP echo $data['dateCreated'];?>" required>
    </div>
    <td>
        <select name='caseType' required>
            <option disabled selected value> -- Select Case Type -- </option>
            <?php 
            $sqlCaseType = mysqli_query($condb, "SELECT DISTINCT caseType FROM case_details");
            while($row = mysqli_fetch_array($sqlCaseType)) {
                $selected = ($data['caseType'] == $row['caseType']) ? 'selected' : '';
                echo "<option value='".$row['caseType']."' $selected>".$row['caseType']."</option>";
            }
            ?>
        </select>
        </td>
        <td>
        <select name='caseStatus' required>
            <option disabled selected value> -- Select Case Status -- </option>
            <?php 
            $sqlCaseStatus = mysqli_query($condb, "SELECT DISTINCT caseStatus FROM case_details");
            while($row = mysqli_fetch_array($sqlCaseStatus)) {
                $selected = ($data['caseStatus'] == $row['caseStatus']) ? 'selected' : '';
                echo "<option value='".$row['caseStatus']."' $selected>".$row['caseStatus']."</option>";
            }
            ?>
        </select>

        </td>

        <td><input type='submit' class='button' value='Kemaskini'></td>
    </tr>
        </div>
        </table>
</form>
        </div>
<!-- (html + PHP) bahagian form yang mempunyai data tamat ---------------------- -->
<nav class="navigation">
        <a href="../index.php" class="nav-link">Home</a>
        <a href="createCaseDetails.php" class="nav-link">Register Case</a>
        <a href="updateCaseDetails.php" class="nav-link">Manage Case</a>
        <a href="#" class="nav-link">Submit Document Here</a>
    </nav>

<!-- (PHP) bahagian mengemaskini data mula ------------------------------------- -->
<?PHP

//Langkah 6 : Menguju kewujudan data POST
if(!empty($_POST))
{
  # L2 : mengambil data POST
  $caseID = $_POST['caseID'];
    $caseType = $_POST['caseType'];
    $caseDesc = $_POST['caseDescription'];
    $caseStatus = $_POST['caseStatus'];
    $clientName = $_POST['clientName'];
    $clientContact = $_POST['clientContactInformation'];
    $dateCreated = $_POST['dateCreated'];
     
    //Langkah 9 : data validation

    //Langkah 9.1 : Menguji format NoKP
     
    //Langkah 9.2 : Mengelakkan dari pengguna meng disable kan akaun sendiri
  
    
    //Langkah 10 : Melaksanakan proses mengemaskini data
    $updateQuery = "UPDATE case_details SET 
                    caseType='$caseType', 
                    caseDescription='$caseDesc', 
                    caseStatus='$caseStatus', 
                    clientName='$clientName', 
                    clientContactInformation='$clientContact', 
                    dateCreated='$dateCreated' 
                    WHERE caseID='$caseID'";
    if(mysqli_query($condb, $updateQuery))
    {
        // langkah 10.1 : Jika berjaya, papar msg dan kembali ke fail pengguna_senarai.php
        echo "<script>alert('Kemaskini berjaya.'); 
        window.location.href='updateCaseDetails.php';</script>";
    }
    else
    {
        // Langkah 10.2 : Jika Gagal, Papar msg dan kembali ke previous page
        echo "<script>alert('Kemaskini tidak berjaya.'); 
        window.history.back();
        </script>";
    }  

mysqli_close($condb);
}

?>
<!-- (PHP) bahagian mengemaskini data tamat ------------------------------------ -->

<?PHP 
include('footer.php'); 
?>