<!--Menghubungkan fail dengan connection dan header file-->
<?PHP
include('connection.php');
?>
<!--Mengisytiharkan pembolehubah css-->
<style>
#para1 {
    font-family: comic;
    font-size: 25px;
    color: darkorchid;
    font-variant: small-caps;
}
#para2 {
    font-family: verdana;
    font-size: 22px;
    color: darkgoldenrod;
}
a:link, a:visited {
  background-color: darkmagenta;
  color: lightcyan;
  padding: 14px 25px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
}
a:hover, a:active {
  background-color: darkturquoise;
}
input[type=text] {
  width: 130px;
  box-sizing: border-box;
  border: 2px solid #ccc;
  border-radius: 4px;
  font-size: 16px;
  background-color: white;
  background-image: url('searchicon.png');
  background-position: 10px 10px; 
  background-repeat: no-repeat;
  padding: 12px;
  -webkit-transition: width 0.4s ease-in-out;
  transition: width 0.4s ease-in-out;
}

input[type=text]:focus {
  width: 200px;
}
select {
  width: 100%;
  padding: 16px 20px;
  border: none;
  border-radius: 4px;
  background-color: #f1f1f1;
}
.button {
  display: inline-block;
  padding: 10px 15px;
  font-size: 15px;
  cursor: pointer;
  text-align: center;
  text-decoration: none;
  outline: none;
  color: #fff;
  background-color: hotpink;
  border: none;
  border-radius: 15px;
  box-shadow: 0 9px #999;
}

.button:hover {background-color: lightpink}

.button:active {
  background-color: lightpink;
  box-shadow: 0 5px #666;
  transform: translateY(4px);
}
</style>
<!--Kawasan form HTML bermula-->
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
<div class="w3-container">
  <div class="w3-panel w3-padding-small w3-pale-green w3-bottombar w3-round-xlarge w3-topbar w3-border-green w3-border">
<p id='para1'>Senarai ahli yang telah berdaftar</p>
</div>
</div>

<?PHP 
// Menyemak data POST
if(!empty($_POST))
{   
    // Mengambil data POST
  
    $caseId=$_POST['caseID'];
    $caseName=$_POST['caseName'];
    $caseType=$_POST['caseType'];
    $caseAction=$_POST['caseAction'];
    //------------- data validation ---------------------------------------------------------
        
    //------------- Data validation ---------------------------------------------------------
    
    //Memasukkan data ke dalam jadual ahli
    
}
?>

<!-- Bahagian papar data (HTML in PHP) mula ------------- -->
<br>
<fieldset style="width:85%">
<div class="w3-panel w3-pale-yellow w3-border w3-border-yellow">
<p id='para2'>Senarai Ahli berdaftar</p>
<div>
<?PHP 
// Lakukan query terhadap pangkalan data
$sqlselect=mysqli_query($condb,"select* from case_management");

echo"<table border='1' width='100%'>
    <tr>
        <th width='5%'>Bil</th>
        <th width='60%'>CaseID</th>
        <th width='15%'>Case Name</th>
        <th width='10%'>Case Type</th> 
        <th width='10%'>Case Action</th>
    </tr>";

$pembilang=1;
while($row=mysqli_fetch_array($sqlselect)){   
    echo"
    <tr>
        <td align='center'>".$pembilang."</td>
        <td>".$row['caseID']."</td>
        <td>".$row['caseName']."</td>
        <td>".$row['caseAction']."</td>
        <td>".$row['caseType']."</td>
		<td align='center'>
		
    </tr>";
    $pembilang++;
}
echo"</table></fieldset><br>";

mysqli_close($condb);
?>
<!-- Bahagian papar data (HTML in PHP) tamat ------------- -->
<?PHP
include('footer.php');
?>