<!--Menghubungkan fail dengan connection dan header file-->
<?PHP
include('header.php');
include('connection.php');
?>
<!--Kawasan form HTML bermula-->
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
 <link rel="stylesheet" type="text/css" href="style.css">
<div class="w3-container">
  <div class="w3-panel w3-padding-small w3-pale-green w3-bottombar w3-round-xlarge w3-topbar w3-border-green w3-border">
<p id='para1'>Case Details</p>
</div>
</div>
<fieldset style="width:100%">
<div class="w3-panel w3-pale-brown w3-leftbar w3-rightbar w3-border-blu">

    <p id='para2'>Fill in the information of the case</p>
</div>
<div class="form-container">
    <form action='' method='POST' lass="contact-form">
    <table>
        <tr>

        <div class="w3-bar">
</div>
        </tr>
        <tr>
    <div class="contact-form-group">
            <input class="contact-form-input" type="text" id="caseID" name="caseID" required placeholder="Please insert exactly 10 digits">
            <label class="contact-form-label" for="caseID">CaseID:</label>
        </div>
        <div class="contact-form-group">
            <input class="contact-form-input" type="text" id="caseDescription" name="caseDescription" required placeholder=" ">
            <label class="contact-form-label" for="caseDescription">Case Description:</label>
        </div>    
        <div class="contact-form-group">
            <input class="contact-form-input" type="text" id="clientName" name="clientName" required placeholder=" ">
            <label class="contact-form-label" for="clientName">Client Name:</label>
        </div>     
        <div class="contact-form-group">
            <input class="contact-form-input" type="text" id="clientContactInformation" name="clientContactInformation" required placeholder=" ">
            <label class="contact-form-label" for="clientContactInformation">Client Contact Information:</label>
        </div>   
    <div>
        <label for="dateCreated">Date Created:</label>
        <input type="date" id="dateCreated" name="dateCreated" required>
    </div>
    <label for="case-documents">Case Documents:</label>
    <input type="file" id="case-documents" name="case_documents">
            
</div>
    <td>

    <select name='caseType' required>
    <option disabled selected value>Case type</option>
    <!-- Fixed options for case status -->
    <option value='Civil law'>Civil law</option>
    <option value='Family law'>Family law</option>
    <option value='Estate law'>Estate law</option>
</select>

            </select>
            </td>      
            <td>
            <select name='caseStatus' required>
    <option disabled selected value>Case status</option>
    <!-- Fixed options for case status -->
    <option value='Open'>Open</option>
    <option value='Pending'>Pending</option>
    <option value='Closed'>Closed</option>
    <option value='In Progress'>In Progress</option>
</select>

            </td> 
            <td><button class='button'<span>Save</span></button></td>
        </tr>
    </table>
    </form>
    
            </div>
            <nav class="navigation">
        <a href="../index.php" class="nav-link">Home</a>
        <a href="updateCaseDetails.php" class="nav-link">Manage Case</a>
    </nav>
</fieldset>
<!-- Bahagian Form (HTML) Tamat -------------------- -->
<!-- Bahagian Insert data (PHP) mula --------------- -->
<?PHP 
// Menyemak data POST
if(!empty($_POST))
{   
    // Mengambil data POST
  
    $caseID=$_POST['caseID'];
    $caseType=$_POST['caseType'];
    $caseDesc=$_POST['caseDescription'];
    $caseStatus=$_POST['caseStatus'];
    $clientName=$_POST['clientName'];
    $clientContact=$_POST['clientContactInformation'];
    $dateCreated=$_POST['dateCreated'];

    //------------- data validation ---------------------------------------------------------
        //Data validation bagi no kad pengenalan bilangan digit & wujud aksara
        
        
            // SQL query to check if the caseID exists in the database
    $sqlcheckcaseID = "SELECT * FROM case_details WHERE caseID = '$caseID'";
    $result = mysqli_query($condb, $sqlcheckcaseID);

    if (mysqli_num_rows($result) > 0) {
        // Case ID already exists in the database
        echo "Case ID '$caseID' already exists in the database.";
    } else {
        // Case ID doesn't exist in the database
        echo "Case ID '$caseID' is available and can be registered.";
    }
    //------------- Data validation ---------------------------------------------------------
    
    //Memasukkan data ke dalam jadual ahli
    if(mysqli_query($condb,"insert into case_details
    (caseID, caseType, caseDescription, caseStatus, clientName, clientContactInformation, created_at) 
    VALUES ('$caseID', '$caseType', '$caseDesc', '$caseStatus', '$clientName', '$clientContact', '$dateCreated')"))
    {
        echo"<script>alert('Pendaftaran berjaya');</script>";
    }
    else
    {
        echo"<script>alert('Pendaftaran Gagal');window.history.back();</script>";
    }
}
?>
<!-- Bahagian Insert data (PHP) tamat --------------- -->



<!-- Bahagian papar data (HTML in PHP) tamat ------------- -->
<?PHP
include('footer.php');
?>